package com.thblue.gamelauncher

import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.widget.Toast
import android.os.SystemClock
import android.view.InputDevice
import android.view.KeyEvent
import android.view.MotionEvent
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat

class MainActivity : ComponentActivity() {
    private lateinit var state: LauncherState
    private val sfx = SoundFx()
    private val showSettings = mutableStateOf(false)
    private val busyText = mutableStateOf<String?>(null)
    private val refreshTick = mutableIntStateOf(0)
    private var lastStick = 0L

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        state = LauncherState(applicationContext)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        hideBars()
        setContent {
            LauncherApp(
                state = state,
                sfx = sfx,
                showSettings = showSettings.value,
                busyText = busyText.value,
                setShowSettings = { showSettings.value = it },
                refreshTick = refreshTick.intValue,
                onLaunch = { launchGame(it) },
                onModeApplied = { Perf.apply(this, it) }
            )
        }
        sfx.enabled = state.sound
        sfx.boot()
    }

    override fun onResume() {
        super.onResume()
        Dnd.restore(this)
        stopService(Intent(this, OverlayService::class.java))
        refreshTick.intValue++
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) hideBars()
    }

    private fun hideBars() {
        val c = WindowInsetsControllerCompat(window, window.decorView)
        c.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        c.hide(WindowInsetsCompat.Type.systemBars())
    }

    private fun launchGame(app: AppEntry) {
        if (busyText.value != null) return
        val intent = packageManager.getLaunchIntentForPackage(app.pkg) ?: return
        if (state.mode == PerfMode.EXTREME) Perf.boost(this, app.pkg)
        if (state.dnd) {
            if (Dnd.hasAccess(this)) {
                Dnd.enable(this)
            } else {
                Toast.makeText(this, "Permita o acesso a Não perturbar nas configurações do Android", Toast.LENGTH_LONG).show()
            }
        }
        if (state.overlay) {
            if (Settings.canDrawOverlays(this)) {
                startForegroundService(Intent(this, OverlayService::class.java))
            } else {
                Toast.makeText(this, "Permita 'Sobrepor a outros apps' para o painel aparecer", Toast.LENGTH_LONG).show()
            }
        }
        sfx.launch()
        if (state.priority) {
            val targets = Priority.targets(this, app.pkg, state.protectedApps)
            if (targets.isNotEmpty()) {
                if (ShizukuHelper.available() && ShizukuHelper.granted()) {
                    busyText.value = "Modo prioridade: fechando ${targets.size} apps…"
                    Thread {
                        ShizukuHelper.forceStop(targets)
                        runOnUiThread {
                            busyText.value = null
                            startActivity(intent)
                        }
                    }.start()
                    return
                }
                val svc = ForceStopService.instance
                if (svc != null) {
                    svc.start(targets, intent)
                    return
                }
                Toast.makeText(this, "Modo prioridade: configure o Shizuku (rápido) ou a acessibilidade nas configurações", Toast.LENGTH_LONG).show()
            }
        }
        startActivity(intent)
    }

    /** Controle: A = confirmar, B = voltar, Y/Start = menu. Teclado: Enter, Esc, setas. */
    override fun dispatchKeyEvent(event: KeyEvent): Boolean {
        when (event.keyCode) {
            KeyEvent.KEYCODE_BUTTON_A -> {
                return super.dispatchKeyEvent(
                    KeyEvent(event.downTime, event.eventTime, event.action, KeyEvent.KEYCODE_DPAD_CENTER, event.repeatCount)
                )
            }
            KeyEvent.KEYCODE_BUTTON_B -> {
                if (event.action == KeyEvent.ACTION_UP) onBackPressedDispatcher.onBackPressed()
                return true
            }
            KeyEvent.KEYCODE_BUTTON_Y,
            KeyEvent.KEYCODE_BUTTON_START,
            KeyEvent.KEYCODE_MENU -> {
                if (event.action == KeyEvent.ACTION_DOWN && event.repeatCount == 0) {
                    sfx.select()
                    showSettings.value = !showSettings.value
                }
                return true
            }
        }
        return super.dispatchKeyEvent(event)
    }

    /** Analógico esquerdo vira setas de navegação. */
    override fun dispatchGenericMotionEvent(ev: MotionEvent): Boolean {
        val isStick = (ev.source and InputDevice.SOURCE_JOYSTICK) == InputDevice.SOURCE_JOYSTICK
        if (isStick && ev.action == MotionEvent.ACTION_MOVE) {
            val x = ev.getAxisValue(MotionEvent.AXIS_X)
            val y = ev.getAxisValue(MotionEvent.AXIS_Y)
            val code = when {
                x < -0.6f -> KeyEvent.KEYCODE_DPAD_LEFT
                x > 0.6f -> KeyEvent.KEYCODE_DPAD_RIGHT
                y < -0.6f -> KeyEvent.KEYCODE_DPAD_UP
                y > 0.6f -> KeyEvent.KEYCODE_DPAD_DOWN
                else -> 0
            }
            val now = SystemClock.uptimeMillis()
            if (code == 0) {
                lastStick = 0
            } else if (now - lastStick > 180) {
                lastStick = now
                sendKey(code)
            }
            return true
        }
        return super.dispatchGenericMotionEvent(ev)
    }

    private fun sendKey(code: Int) {
        val t = SystemClock.uptimeMillis()
        super.dispatchKeyEvent(KeyEvent(t, t, KeyEvent.ACTION_DOWN, code, 0))
        super.dispatchKeyEvent(KeyEvent(t, t, KeyEvent.ACTION_UP, code, 0))
    }
}
