package com.thblue.gamelauncher

import android.app.ActivityManager
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.hardware.display.DisplayManager
import android.os.BatteryManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.view.Display
import android.view.Gravity
import android.view.WindowManager
import android.widget.TextView
import java.io.File

/** Painel flutuante com Hz, CPU, temperatura, RAM e bateria, exibido sobre o jogo. */
class OverlayService : Service() {
    private var wm: WindowManager? = null
    private var tv: TextView? = null
    private val handler = Handler(Looper.getMainLooper())
    private val cpuTempPath: String? by lazy { findCpuTempPath() }

    private val tick = object : Runnable {
        override fun run() {
            update()
            handler.postDelayed(this, 1000)
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startAsForeground()
        if (tv == null) addOverlay()
        handler.removeCallbacks(tick)
        handler.post(tick)
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        handler.removeCallbacks(tick)
        val v = tv
        if (v != null) runCatching { wm?.removeView(v) }
        tv = null
        super.onDestroy()
    }

    private fun startAsForeground() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL, "Painel de desempenho", NotificationManager.IMPORTANCE_MIN)
        )
        val n = Notification.Builder(this, CHANNEL)
            .setContentTitle("Painel de desempenho ativo")
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setOngoing(true)
            .build()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(1, n)
        }
    }

    private fun addOverlay() {
        val density = resources.displayMetrics.density
        val t = TextView(this)
        t.typeface = Typeface.MONOSPACE
        t.textSize = 11f
        t.setTextColor(Color.WHITE)
        t.setPadding((8 * density).toInt(), (6 * density).toInt(), (8 * density).toInt(), (6 * density).toInt())
        val bg = GradientDrawable()
        bg.setColor(0xB3000000.toInt())
        bg.cornerRadius = 10 * density
        t.background = bg

        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.START
        lp.x = (12 * density).toInt()
        lp.y = (36 * density).toInt()

        val manager = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        wm = manager
        runCatching {
            manager.addView(t, lp)
            tv = t
        }
    }

    private fun update() {
        val t = tv ?: return
        val dm = getSystemService(Context.DISPLAY_SERVICE) as DisplayManager
        val hz = dm.getDisplay(Display.DEFAULT_DISPLAY)?.refreshRate

        val am = getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val mi = ActivityManager.MemoryInfo()
        am.getMemoryInfo(mi)
        val used = mi.totalMem - mi.availMem
        val ramPct = if (mi.totalMem > 0) used * 100 / mi.totalMem else 0L

        val b = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val level = b?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
        val scale = b?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100
        val pct = if (level >= 0 && scale > 0) level * 100 / scale else -1
        val batTemp = (b?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) ?: 0) / 10.0
        val st = b?.getIntExtra(BatteryManager.EXTRA_STATUS, -1) ?: -1
        val charging = st == BatteryManager.BATTERY_STATUS_CHARGING || st == BatteryManager.BATTERY_STATUS_FULL

        val raw = cpuTempPath?.let { readLong(it) }
        val cpuT = raw?.let { if (it > 1000) it / 1000.0 else it.toDouble() }?.takeIf { it in 1.0..120.0 }

        val lines = ArrayList<String>()
        lines.add("Tela  " + (if (hz != null) "${hz.toInt()} Hz" else "--"))
        lines.add(cpuLine())
        lines.add(
            "Temp  " + (if (cpuT != null) "CPU ${"%.0f".format(cpuT)}° " else "") +
                "Bat ${"%.1f".format(batTemp)}°"
        )
        lines.add("RAM   ${"%.1f".format(used / 1e9)}/${"%.1f".format(mi.totalMem / 1e9)} GB  $ramPct%")
        lines.add("Bat   " + (if (pct >= 0) "$pct%" else "--") + (if (charging) " carregando" else ""))
        t.text = lines.joinToString("\n")
    }

    private fun cpuLine(): String {
        val n = Runtime.getRuntime().availableProcessors()
        var maxCur = 0L
        var ratioSum = 0.0
        var count = 0
        for (i in 0 until n) {
            val base = "/sys/devices/system/cpu/cpu$i/cpufreq/"
            val cur = readLong(base + "scaling_cur_freq") ?: continue
            val max = readLong(base + "cpuinfo_max_freq") ?: continue
            if (max <= 0) continue
            if (cur > maxCur) maxCur = cur
            ratioSum += cur.toDouble() / max
            count++
        }
        if (count == 0) return "CPU   indisponível"
        return "CPU   ${maxCur / 1000} MHz ~${(ratioSum / count * 100).toInt()}%"
    }

    private fun readLong(path: String): Long? =
        runCatching { File(path).readText().trim().toLongOrNull() }.getOrNull()

    private fun findCpuTempPath(): String? {
        val zones = File("/sys/class/thermal").listFiles()
            ?.filter { it.name.startsWith("thermal_zone") } ?: return null
        for (key in listOf("cpu", "soc", "tsens")) {
            for (z in zones) {
                val type = runCatching { File(z, "type").readText().trim().lowercase() }.getOrNull() ?: continue
                val tempPath = File(z, "temp").path
                if (type.contains(key) && readLong(tempPath) != null) return tempPath
            }
        }
        return null
    }

    companion object {
        private const val CHANNEL = "overlay"
    }
}
