# Shizuku é chamado por reflexão (Shizuku.newProcess), então não pode ser renomeado.
-keep class rikka.shizuku.Shizuku { *; }
-keep class rikka.shizuku.ShizukuRemoteProcess { *; }
-dontwarn rikka.**
