package com.thblue.gamelauncher

import android.app.Activity
import android.app.ActivityManager
import android.content.Context
import android.content.pm.ApplicationInfo
import android.view.WindowManager

object Perf {
    /** Aplica o modo na janela do launcher: taxa de atualização, brilho e tela ligada. */
    @Suppress("DEPRECATION")
    fun apply(activity: Activity, mode: PerfMode) {
        val w = activity.window
        val lp = w.attributes
        val display = activity.windowManager.defaultDisplay
        val cur = display.mode
        val same = display.supportedModes.filter {
            it.physicalWidth == cur.physicalWidth && it.physicalHeight == cur.physicalHeight
        }
        lp.preferredDisplayModeId = when (mode) {
            PerfMode.EXTREME -> same.maxByOrNull { it.refreshRate }?.modeId ?: 0
            PerfMode.ECONOMY -> same.minByOrNull { it.refreshRate }?.modeId ?: 0
            PerfMode.PERFORMANCE -> 0
        }
        lp.screenBrightness = if (mode == PerfMode.ECONOMY) {
            0.35f
        } else {
            WindowManager.LayoutParams.BRIGHTNESS_OVERRIDE_NONE
        }
        w.attributes = lp
        if (mode == PerfMode.EXTREME) {
            w.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        } else {
            w.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        }
    }

    /** Pede ao Android para encerrar processos em segundo plano de outros apps (exceto o jogo). */
    fun boost(ctx: Context, keepPkg: String) {
        val am = ctx.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        ctx.packageManager.getInstalledApplications(0).forEach {
            val isSystem = (it.flags and ApplicationInfo.FLAG_SYSTEM) != 0
            if (!isSystem && it.packageName != ctx.packageName && it.packageName != keepPkg) {
                runCatching { am.killBackgroundProcesses(it.packageName) }
            }
        }
    }
}
