package com.thblue.gamelauncher

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.provider.Settings

object Priority {
    /**
     * Apps que serão fechados: só apps instalados pelo usuário e ainda não parados.
     * Ficam de fora: o launcher, o jogo, apps protegidos, teclado, launcher padrão e serviços de acessibilidade ativos.
     */
    fun targets(ctx: Context, gamePkg: String, protectedPkgs: Collection<String>): List<String> {
        val pm = ctx.packageManager
        val skip = HashSet<String>()
        skip.add(ctx.packageName)
        skip.add(gamePkg)
        skip.addAll(protectedPkgs)

        Settings.Secure.getString(ctx.contentResolver, Settings.Secure.DEFAULT_INPUT_METHOD)
            ?.let { ComponentName.unflattenFromString(it)?.packageName }
            ?.let { skip.add(it) }

        Settings.Secure.getString(ctx.contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES)
            ?.split(":")
            ?.forEach { s -> ComponentName.unflattenFromString(s)?.packageName?.let { skip.add(it) } }

        val home = pm.resolveActivity(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME), 0)
        home?.activityInfo?.packageName?.let { skip.add(it) }

        return pm.getInstalledApplications(0)
            .filter { ai ->
                (ai.flags and ApplicationInfo.FLAG_SYSTEM) == 0 &&
                    (ai.flags and ApplicationInfo.FLAG_STOPPED) == 0 &&
                    ai.packageName !in skip
            }
            .map { it.packageName }
    }
}
