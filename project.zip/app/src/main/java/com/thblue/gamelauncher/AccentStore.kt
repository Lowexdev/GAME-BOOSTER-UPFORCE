package com.thblue.gamelauncher

import android.content.Context

/** Cor de destaque (launcher e painel do jogo). Padrão: azul. Guardada por perfil. */
object AccentStore {
    val presets = intArrayOf(
        0xFF3B82F6.toInt(), // azul (padrão)
        0xFF06B6D4.toInt(), // ciano
        0xFF22C55E.toInt(), // verde
        0xFFFACC15.toInt(), // amarelo
        0xFFF97316.toInt(), // laranja
        0xFFEF4444.toInt(), // vermelho
        0xFFEC4899.toInt(), // rosa
        0xFFA855F7.toInt()  // roxo
    )
    val DEFAULT: Int get() = presets[0]

    // Ordem antiga (índice salvo pelas versões anteriores).
    private val legacy = intArrayOf(
        0xFF3B82F6.toInt(), 0xFF22C55E.toInt(), 0xFFEF4444.toInt(),
        0xFFA855F7.toInt(), 0xFFF59E0B.toInt(), 0xFF06B6D4.toInt()
    )

    private fun sp(ctx: Context) = ctx.getSharedPreferences("launcher", Context.MODE_PRIVATE)

    private fun currentProfile(ctx: Context): String? = sp(ctx).getString("current", null)

    fun read(ctx: Context): Int = readFor(ctx, currentProfile(ctx))

    fun readFor(ctx: Context, cur: String?): Int {
        val s = sp(ctx)
        if (cur == null) return DEFAULT
        if (s.contains("p.$cur.accentColor")) return s.getInt("p.$cur.accentColor", DEFAULT)
        return legacy.getOrElse(s.getInt("p.$cur.accent", 0)) { DEFAULT }
    }

    fun write(ctx: Context, color: Int) {
        val cur = currentProfile(ctx) ?: return
        sp(ctx).edit().putInt("p.$cur.accentColor", color).apply()
    }

    /** Lado em que a aba do painel fica durante o jogo: false = esquerda, true = direita. */
    fun readRight(ctx: Context): Boolean = sp(ctx).getBoolean("overlay_right", false)

    fun writeRight(ctx: Context, right: Boolean) {
        sp(ctx).edit().putBoolean("overlay_right", right).apply()
    }

    /** Posição vertical da aba, como fração da tela (0 = topo, 1 = base). Padrão: meio. */
    fun readHandleY(ctx: Context): Float = sp(ctx).getFloat("overlay_y", 0.5f).coerceIn(0f, 1f)

    fun writeHandleY(ctx: Context, frac: Float) {
        sp(ctx).edit().putFloat("overlay_y", frac.coerceIn(0f, 1f)).apply()
    }
}
