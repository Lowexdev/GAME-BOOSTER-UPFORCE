package com.thblue.gamelauncher

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.media.ExifInterface
import android.net.Uri
import java.io.File

/** Foto de fundo personalizada (por perfil): uma para o launcher e outra para o painel do jogo. */
object BgStore {
    const val LAUNCHER = "launcher"
    const val PANEL = "panel"
    private const val MAX_SIDE = 1280

    private fun sp(ctx: Context) = ctx.getSharedPreferences("launcher", Context.MODE_PRIVATE)
    private fun key(profile: String, kind: String) = "p.$profile.bg_$kind"

    fun pathFor(ctx: Context, profile: String?, kind: String): String? {
        if (profile == null) return null
        return sp(ctx).getString(key(profile, kind), null)?.takeIf { File(it).exists() }
    }

    fun current(ctx: Context, kind: String): String? = pathFor(ctx, sp(ctx).getString("current", null), kind)

    /** Lê a foto escolhida, reduz (máx. 1280 px), corrige a rotação e guarda no app. */
    fun save(ctx: Context, profile: String, kind: String, uri: Uri): String? = runCatching {
        val cr = ctx.contentResolver
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        cr.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
        var sample = 1
        while (maxOf(bounds.outWidth, bounds.outHeight) / (sample * 2) >= MAX_SIDE) sample *= 2
        var bmp = cr.openInputStream(uri)?.use {
            BitmapFactory.decodeStream(it, null, BitmapFactory.Options().apply { inSampleSize = sample })
        } ?: return null
        val rotation = cr.openInputStream(uri)?.use {
            when (ExifInterface(it).getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL)) {
                ExifInterface.ORIENTATION_ROTATE_90 -> 90f
                ExifInterface.ORIENTATION_ROTATE_180 -> 180f
                ExifInterface.ORIENTATION_ROTATE_270 -> 270f
                else -> 0f
            }
        } ?: 0f
        val scale = MAX_SIDE.toFloat() / maxOf(bmp.width, bmp.height)
        if (rotation != 0f || scale < 1f) {
            val m = Matrix().apply {
                if (scale < 1f) postScale(scale, scale)
                if (rotation != 0f) postRotate(rotation)
            }
            bmp = Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, m, true)
        }
        val out = File(ctx.filesDir, "bg_${kind}_${System.currentTimeMillis()}.jpg")
        out.outputStream().use { bmp.compress(Bitmap.CompressFormat.JPEG, 86, it) }
        pathFor(ctx, profile, kind)?.let { File(it).delete() }
        sp(ctx).edit().putString(key(profile, kind), out.path).apply()
        out.path
    }.getOrNull()

    /** Usa a foto de um lugar (ex.: launcher) também em outro (ex.: painel). */
    fun copy(ctx: Context, profile: String, from: String, to: String): String? {
        val src = pathFor(ctx, profile, from) ?: return null
        val out = File(ctx.filesDir, "bg_${to}_${System.currentTimeMillis()}.jpg")
        return runCatching {
            File(src).copyTo(out, overwrite = true)
            pathFor(ctx, profile, to)?.let { File(it).delete() }
            sp(ctx).edit().putString(key(profile, to), out.path).apply()
            out.path
        }.getOrNull()
    }

    fun clear(ctx: Context, profile: String, kind: String) {
        pathFor(ctx, profile, kind)?.let { File(it).delete() }
        sp(ctx).edit().remove(key(profile, kind)).apply()
    }

    fun load(path: String): Bitmap? = runCatching { BitmapFactory.decodeFile(path) }.getOrNull()
}
