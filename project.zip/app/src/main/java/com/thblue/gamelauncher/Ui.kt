package com.thblue.gamelauncher

import androidx.activity.compose.BackHandler
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.hoverable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsHoveredAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.itemsIndexed
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.compositeOver
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.graphics.drawable.toBitmap
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

val Accents = listOf(
    Color(0xFF3B82F6), Color(0xFF22C55E), Color(0xFFEF4444),
    Color(0xFFA855F7), Color(0xFFF59E0B), Color(0xFF06B6D4)
)

val LocalSfx = staticCompositionLocalOf<SoundFx> { error("SoundFx não fornecido") }
val LocalAnimate = compositionLocalOf { true }

@Composable
fun LauncherApp(
    state: LauncherState,
    sfx: SoundFx,
    showSettings: Boolean,
    setShowSettings: (Boolean) -> Unit,
    refreshTick: Int,
    onLaunch: (AppEntry) -> Unit,
    onModeApplied: (PerfMode) -> Unit
) {
    val accent = Accents[state.accentIndex.coerceIn(0, Accents.lastIndex)]
    SideEffect { sfx.enabled = state.sound }
    LaunchedEffect(refreshTick) { state.refreshApps() }
    LaunchedEffect(state.mode) { onModeApplied(state.mode) }

    val base = Color(0xFF0B1424)
    CompositionLocalProvider(
        LocalSfx provides sfx,
        LocalAnimate provides (state.mode != PerfMode.ECONOMY)
    ) {
        MaterialTheme(colorScheme = darkColorScheme(primary = accent)) {
            Box(
                Modifier
                    .fillMaxSize()
                    .background(
                        Brush.verticalGradient(
                            listOf(Color(0xFF04060B), base, accent.copy(alpha = 0.35f).compositeOver(base))
                        )
                    )
            ) {
                if (showSettings) {
                    SettingsScreen(state, accent) { setShowSettings(false) }
                } else {
                    Home(state, accent, onLaunch) { setShowSettings(true) }
                }
            }
        }
    }
}

/** Superfície focável: reage a controle (foco), teclado (foco + Enter) e mouse (hover + clique). */
@Composable
fun FocusSurface(
    accent: Color,
    modifier: Modifier = Modifier,
    shape: Shape = RoundedCornerShape(16.dp),
    focusRequester: FocusRequester? = null,
    onClick: () -> Unit,
    content: @Composable BoxScope.(Boolean) -> Unit
) {
    val sfx = LocalSfx.current
    val animate = LocalAnimate.current
    val interaction = remember { MutableInteractionSource() }
    val hovered by interaction.collectIsHoveredAsState()
    var focused by remember { mutableStateOf(false) }
    val active = focused || hovered
    val scale by animateFloatAsState(
        targetValue = if (active) 1.06f else 1f,
        animationSpec = tween(if (animate) 120 else 0),
        label = "scale"
    )
    val fr = focusRequester ?: remember { FocusRequester() }
    LaunchedEffect(hovered) {
        if (hovered) runCatching { fr.requestFocus() }
    }
    Box(
        modifier
            .scale(scale)
            .clip(shape)
            .background(if (active) Color(0xFF1E2A3F) else Color(0xFF121A2A))
            .border(
                if (active) 3.dp else 1.dp,
                if (active) accent else Color(0x22FFFFFF),
                shape
            )
            .focusRequester(fr)
            .onFocusChanged {
                if (it.isFocused && !focused) sfx.move()
                focused = it.isFocused
            }
            .hoverable(interaction)
            .clickable(interactionSource = interaction, indication = null) {
                sfx.select()
                onClick()
            }
    ) { content(active) }
}

@Composable
private fun Chip(text: String, accent: Color) {
    Text(
        text,
        color = Color.White,
        fontSize = 13.sp,
        maxLines = 1,
        modifier = Modifier
            .clip(RoundedCornerShape(50))
            .background(accent.copy(alpha = 0.25f))
            .padding(horizontal = 12.dp, vertical = 6.dp)
    )
}

@Composable
fun Home(state: LauncherState, accent: Color, onLaunch: (AppEntry) -> Unit, openSettings: () -> Unit) {
    val games = state.games
    val firstFr = remember { FocusRequester() }
    var clock by remember { mutableStateOf("") }

    LaunchedEffect(Unit) {
        val f = SimpleDateFormat("HH:mm", Locale.getDefault())
        while (true) {
            clock = f.format(Date())
            delay(20_000)
        }
    }
    LaunchedEffect(games.isNotEmpty()) {
        if (games.isNotEmpty()) {
            delay(150)
            runCatching { firstFr.requestFocus() }
        }
    }

    Column(
        Modifier
            .fillMaxSize()
            .systemBarsPadding()
            .padding(horizontal = 28.dp, vertical = 16.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("GAMES", color = Color.White, fontSize = 26.sp, fontWeight = FontWeight.Black, letterSpacing = 4.sp)
            Spacer(Modifier.weight(1f))
            Chip(state.current, accent)
            Spacer(Modifier.width(8.dp))
            Chip(state.mode.label, accent)
            Spacer(Modifier.width(14.dp))
            Text(clock, color = Color.White, fontSize = 18.sp)
            Spacer(Modifier.width(14.dp))
            FocusSurface(accent, Modifier.size(44.dp), CircleShape, onClick = openSettings) {
                Text("⚙", color = Color.White, fontSize = 22.sp, modifier = Modifier.align(Alignment.Center))
            }
        }

        if (games.isEmpty()) {
            Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("Nenhum jogo encontrado", color = Color.White, fontSize = 20.sp)
                    Spacer(Modifier.height(6.dp))
                    Text(
                        "Abra as configurações e escolha quais apps aparecem aqui.",
                        color = Color(0xFF9AA4B2), fontSize = 14.sp, textAlign = TextAlign.Center
                    )
                    Spacer(Modifier.height(16.dp))
                    FocusSurface(accent, onClick = openSettings) {
                        Text("Abrir configurações", color = Color.White, modifier = Modifier.padding(20.dp, 12.dp))
                    }
                }
            }
        } else {
            LazyVerticalGrid(
                columns = GridCells.Adaptive(150.dp),
                horizontalArrangement = Arrangement.spacedBy(16.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp),
                contentPadding = PaddingValues(vertical = 20.dp, horizontal = 10.dp),
                modifier = Modifier.weight(1f)
            ) {
                itemsIndexed(games, key = { _, g -> g.pkg }) { i, g ->
                    GameCard(g, accent, if (i == 0) firstFr else null) { onLaunch(g) }
                }
            }
        }

        Text(
            "A / Enter  Abrir      B / Esc  Voltar      Y / Start  Configurações",
            color = Color(0xFF7C8798), fontSize = 12.sp,
            modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center
        )
    }
}

@Composable
fun GameCard(app: AppEntry, accent: Color, fr: FocusRequester?, onClick: () -> Unit) {
    val pm = LocalContext.current.packageManager
    val icon by produceState<ImageBitmap?>(null, app.pkg) {
        value = withContext(Dispatchers.Default) {
            runCatching { pm.getApplicationIcon(app.pkg).toBitmap(160, 160).asImageBitmap() }.getOrNull()
        }
    }
    FocusSurface(accent, Modifier.fillMaxWidth().height(170.dp), RoundedCornerShape(20.dp), fr, onClick) {
        Column(
            Modifier.fillMaxSize().padding(12.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            val bmp = icon
            if (bmp != null) {
                Image(bmp, contentDescription = null, modifier = Modifier.size(84.dp))
            } else {
                Box(Modifier.size(84.dp))
            }
            Spacer(Modifier.height(12.dp))
            Text(
                app.label, color = Color.White, fontSize = 14.sp, maxLines = 2,
                overflow = TextOverflow.Ellipsis, textAlign = TextAlign.Center
            )
        }
    }
}

private enum class Page { MAIN, GAMES }

@Composable
fun SettingsScreen(state: LauncherState, accent: Color, close: () -> Unit) {
    val sfx = LocalSfx.current
    var page by remember { mutableStateOf(Page.MAIN) }
    var showDialog by remember { mutableStateOf(false) }

    BackHandler(true) {
        sfx.back()
        if (page == Page.GAMES) page = Page.MAIN else close()
    }

    Column(
        Modifier
            .fillMaxSize()
            .systemBarsPadding()
            .padding(horizontal = 28.dp, vertical = 16.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            FocusSurface(
                accent, Modifier.size(44.dp), CircleShape,
                onClick = { if (page == Page.GAMES) page = Page.MAIN else close() }
            ) {
                Text("←", color = Color.White, fontSize = 22.sp, modifier = Modifier.align(Alignment.Center))
            }
            Spacer(Modifier.width(14.dp))
            Text(
                if (page == Page.MAIN) "Configurações" else "Gerenciar jogos",
                color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold
            )
        }
        Spacer(Modifier.height(12.dp))

        if (page == Page.GAMES) {
            Text(
                "Marque o que aparece na tela inicial deste perfil.",
                color = Color(0xFF9AA4B2), fontSize = 13.sp
            )
            LazyColumn(
                verticalArrangement = Arrangement.spacedBy(10.dp),
                contentPadding = PaddingValues(vertical = 14.dp, horizontal = 8.dp),
                modifier = Modifier.weight(1f)
            ) {
                items(state.apps, key = { it.pkg }) { app ->
                    val visible = state.isVisible(app)
                    FocusSurface(accent, Modifier.fillMaxWidth(), onClick = { state.toggle(app) }) {
                        Row(Modifier.padding(16.dp, 12.dp), verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text(app.label, color = Color.White, fontSize = 15.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                if (app.isGame) Text("Detectado como jogo", color = Color(0xFF7C8798), fontSize = 11.sp)
                            }
                            Text(
                                if (visible) "✓ Visível" else "Oculto",
                                color = if (visible) accent else Color(0xFF7C8798), fontSize = 13.sp
                            )
                        }
                    }
                }
            }
        } else {
            Column(
                Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(horizontal = 8.dp, vertical = 6.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                SectionTitle("Perfil")
                state.profiles.forEach { p ->
                    FocusSurface(accent, Modifier.fillMaxWidth(), onClick = { state.switchTo(p) }) {
                        Row(Modifier.padding(16.dp, 12.dp), verticalAlignment = Alignment.CenterVertically) {
                            Text(p, color = Color.White, fontSize = 15.sp, modifier = Modifier.weight(1f))
                            if (p == state.current) Text("✓ Ativo", color = accent, fontSize = 13.sp)
                        }
                    }
                }
                FocusSurface(accent, Modifier.fillMaxWidth(), onClick = { showDialog = true }) {
                    Text("＋ Novo perfil", color = Color.White, fontSize = 15.sp, modifier = Modifier.padding(16.dp, 12.dp))
                }
                if (state.profiles.size > 1) {
                    FocusSurface(accent, Modifier.fillMaxWidth(), onClick = { state.deleteProfile(state.current) }) {
                        Text(
                            "Excluir perfil “${state.current}”",
                            color = Color(0xFFF87171), fontSize = 15.sp, modifier = Modifier.padding(16.dp, 12.dp)
                        )
                    }
                }

                SectionTitle("Modo de desempenho")
                PerfMode.values().forEach { m ->
                    FocusSurface(accent, Modifier.fillMaxWidth(), onClick = { state.changeMode(m) }) {
                        Row(Modifier.padding(16.dp, 12.dp), verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text(m.label, color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
                                Text(m.desc, color = Color(0xFF9AA4B2), fontSize = 12.sp)
                            }
                            if (m == state.mode) Text("✓", color = accent, fontSize = 18.sp)
                        }
                    }
                }

                SectionTitle("Cor de destaque")
                Row(horizontalArrangement = Arrangement.spacedBy(14.dp), modifier = Modifier.padding(vertical = 6.dp)) {
                    Accents.forEachIndexed { i, c ->
                        FocusSurface(c, Modifier.size(46.dp), CircleShape, onClick = { state.setAccent(i) }) {
                            Box(
                                Modifier
                                    .fillMaxSize()
                                    .padding(if (i == state.accentIndex) 6.dp else 11.dp)
                                    .background(c, CircleShape)
                            )
                        }
                    }
                }

                SectionTitle("Sons")
                FocusSurface(accent, Modifier.fillMaxWidth(), onClick = { state.changeSound(!state.sound) }) {
                    Row(Modifier.padding(16.dp, 12.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text("Sons de navegação", color = Color.White, fontSize = 15.sp, modifier = Modifier.weight(1f))
                        Switch(checked = state.sound, onCheckedChange = null)
                    }
                }

                SectionTitle("Jogos")
                FocusSurface(accent, Modifier.fillMaxWidth(), onClick = { page = Page.GAMES }) {
                    Text("Gerenciar jogos exibidos", color = Color.White, fontSize = 15.sp, modifier = Modifier.padding(16.dp, 12.dp))
                }
                Spacer(Modifier.height(24.dp))
            }
        }
    }

    if (showDialog) {
        var name by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { showDialog = false },
            title = { Text("Novo perfil") },
            text = {
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it.take(16) },
                    singleLine = true,
                    label = { Text("Nome") }
                )
            },
            confirmButton = {
                TextButton(onClick = { state.createProfile(name); showDialog = false }) { Text("Criar") }
            },
            dismissButton = {
                TextButton(onClick = { showDialog = false }) { Text("Cancelar") }
            }
        )
    }
}

@Composable
private fun SectionTitle(text: String) {
    Text(
        text.uppercase(), color = Color(0xFF7C8798), fontSize = 12.sp,
        fontWeight = FontWeight.Bold, letterSpacing = 2.sp,
        modifier = Modifier.padding(top = 14.dp, bottom = 2.dp)
    )
}
