package com.thblue.gamelauncher

import androidx.activity.compose.BackHandler
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.hoverable
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.layout.ContentScale
import kotlinx.coroutines.launch
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.foundation.interaction.collectIsHoveredAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.itemsIndexed
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.compositeOver
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.graphics.drawable.toBitmap
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

val Accents = AccentStore.presets.map { Color(it) }

val LocalSfx = staticCompositionLocalOf<SoundFx> { error("SoundFx não fornecido") }
val LocalAnimate = compositionLocalOf { true }

@Composable
fun LauncherApp(
    state: LauncherState,
    sfx: SoundFx,
    showSettings: Boolean,
    busyText: String?,
    setShowSettings: (Boolean) -> Unit,
    refreshTick: Int,
    onLaunch: (AppEntry) -> Unit,
    onModeApplied: (PerfMode) -> Unit
) {
    val accent = Color(state.accentColor)
    SideEffect { sfx.enabled = state.sound }
    LaunchedEffect(refreshTick) { state.refreshApps() }
    LaunchedEffect(state.mode) { onModeApplied(state.mode) }

    val base = Color(0xFF0B1424)
    CompositionLocalProvider(
        LocalSfx provides sfx,
        LocalAnimate provides (state.mode != PerfMode.ECONOMY)
    ) {
        MaterialTheme(colorScheme = darkColorScheme(primary = accent)) {
            Box(
                Modifier
                    .fillMaxSize()
                    .background(
                        Brush.verticalGradient(
                            listOf(Color(0xFF04060B), base, accent.copy(alpha = 0.35f).compositeOver(base))
                        )
                    )
            ) {
                val bgPath = state.bgLauncher
                val bgPhoto by produceState<ImageBitmap?>(null, bgPath) {
                    value = if (bgPath == null) null
                    else withContext(Dispatchers.IO) { BgStore.load(bgPath)?.asImageBitmap() }
                }
                bgPhoto?.let {
                    Image(it, contentDescription = null, modifier = Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
                    Box(Modifier.fillMaxSize().background(Color(0x99040810)))
                }
                if (showSettings) {
                    SettingsScreen(state, accent) { setShowSettings(false) }
                } else {
                    Home(state, accent, onLaunch) { setShowSettings(true) }
                }
                if (busyText != null) {
                    Box(
                        Modifier.fillMaxSize().background(Color(0xE6000000)).pointerInput(Unit) {},
                        contentAlignment = Alignment.Center
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            CircularProgressIndicator(color = accent)
                            Spacer(Modifier.height(16.dp))
                            Text(busyText, color = Color.White, fontSize = 16.sp)
                        }
                    }
                }
            }
        }
    }
}

/** Superfície focável: reage a controle (foco), teclado (foco + Enter) e mouse (hover + clique). */
@Composable
fun FocusSurface(
    accent: Color,
    modifier: Modifier = Modifier,
    shape: Shape = RoundedCornerShape(16.dp),
    focusRequester: FocusRequester? = null,
    onClick: () -> Unit,
    content: @Composable BoxScope.(Boolean) -> Unit
) {
    val sfx = LocalSfx.current
    val animate = LocalAnimate.current
    val interaction = remember { MutableInteractionSource() }
    val hovered by interaction.collectIsHoveredAsState()
    var focused by remember { mutableStateOf(false) }
    val active = focused || hovered
    val scale = animateFloatAsState(
        targetValue = if (active) 1.06f else 1f,
        animationSpec = tween(if (animate) 120 else 0),
        label = "scale"
    )
    val fr = focusRequester ?: remember { FocusRequester() }
    LaunchedEffect(hovered) {
        if (hovered) runCatching { fr.requestFocus() }
    }
    Box(
        modifier
            .graphicsLayer {
                scaleX = scale.value
                scaleY = scale.value
            }
            .clip(shape)
            .background(if (active) Color(0xFF1E2A3F) else Color(0xFF121A2A))
            .border(
                if (active) 3.dp else 1.dp,
                if (active) accent else Color(0x22FFFFFF),
                shape
            )
            .focusRequester(fr)
            .onFocusChanged {
                if (it.isFocused && !focused) sfx.move()
                focused = it.isFocused
            }
            .hoverable(interaction)
            .clickable(interactionSource = interaction, indication = null) {
                sfx.select()
                onClick()
            }
    ) { content(active) }
}

@Composable
private fun Chip(text: String, accent: Color) {
    Text(
        text,
        color = Color.White,
        fontSize = 13.sp,
        maxLines = 1,
        modifier = Modifier
            .clip(RoundedCornerShape(50))
            .background(accent.copy(alpha = 0.25f))
            .padding(horizontal = 12.dp, vertical = 6.dp)
    )
}

@Composable
fun Home(state: LauncherState, accent: Color, onLaunch: (AppEntry) -> Unit, openSettings: () -> Unit) {
    val games by remember { derivedStateOf { state.games } }
    val firstFr = remember { FocusRequester() }
    var clock by remember { mutableStateOf("") }
    var showPin by remember { mutableStateOf(false) }
    val ctx = LocalContext.current
    val activity = ctx as? android.app.Activity
    val requestUnlock: () -> Unit = {
        when {
            state.unlocked -> state.lock()
            !state.isSetUp -> showPin = true
            state.bioEnabled && Bio.available(ctx) -> Bio.prompt(
                activity, "Jogos ocultos", if (state.hasPin) "Usar PIN" else "Cancelar",
                onSuccess = { state.unlockWithBio() },
                onNegative = { if (state.hasPin) showPin = true }
            )
            state.hasPin -> showPin = true
            else -> android.widget.Toast.makeText(ctx, "Digital indisponível neste momento", android.widget.Toast.LENGTH_SHORT).show()
        }
    }

    LaunchedEffect(Unit) {
        val f = SimpleDateFormat("HH:mm", Locale.getDefault())
        while (true) {
            clock = f.format(Date())
            delay(20_000)
        }
    }
    LaunchedEffect(games.isNotEmpty()) {
        if (games.isNotEmpty()) {
            delay(150)
            runCatching { firstFr.requestFocus() }
        }
    }

    Column(
        Modifier
            .fillMaxSize()
            .systemBarsPadding()
            .padding(horizontal = 28.dp, vertical = 16.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
                "GAMES", color = Color.White, fontSize = 26.sp, fontWeight = FontWeight.Black, letterSpacing = 4.sp,
                // segurar o título: abre/fecha os jogos secretos
                modifier = Modifier.pointerInput(Unit) {
                    detectTapGestures(onLongPress = { requestUnlock() })
                }
            )
            Spacer(Modifier.weight(1f))
            if (state.unlocked) {
                Chip("🔓 Oculto", accent)
                Spacer(Modifier.width(8.dp))
            }
            Chip(state.current, accent)
            Spacer(Modifier.width(8.dp))
            Chip(state.mode.label, accent)
            Spacer(Modifier.width(14.dp))
            Text(clock, color = Color.White, fontSize = 18.sp)
            Spacer(Modifier.width(14.dp))
            FocusSurface(accent, Modifier.size(44.dp), CircleShape, onClick = openSettings) {
                Text("⚙", color = Color.White, fontSize = 22.sp, modifier = Modifier.align(Alignment.Center))
            }
        }

        if (games.isEmpty()) {
            Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("Nenhum jogo encontrado", color = Color.White, fontSize = 20.sp)
                    Spacer(Modifier.height(6.dp))
                    Text(
                        "Abra as configurações e escolha quais apps aparecem aqui.",
                        color = Color(0xFF9AA4B2), fontSize = 14.sp, textAlign = TextAlign.Center
                    )
                    Spacer(Modifier.height(16.dp))
                    FocusSurface(accent, onClick = openSettings) {
                        Text("Abrir configurações", color = Color.White, modifier = Modifier.padding(20.dp, 12.dp))
                    }
                }
            }
        } else {
            LazyVerticalGrid(
                columns = GridCells.Adaptive(150.dp),
                horizontalArrangement = Arrangement.spacedBy(16.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp),
                contentPadding = PaddingValues(vertical = 20.dp, horizontal = 10.dp),
                modifier = Modifier.weight(1f)
            ) {
                itemsIndexed(games, key = { _, g -> g.pkg }) { i, g ->
                    GameCard(g, accent, if (i == 0) firstFr else null) { onLaunch(g) }
                }
            }
        }

        Text(
            "A / Enter  Abrir      B / Esc  Voltar      Y / Start  Configurações",
            color = Color(0xFF7C8798), fontSize = 12.sp,
            modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center
        )
    }

    if (showPin) {
        var pin by remember { mutableStateOf("") }
        var error by remember { mutableStateOf(false) }
        val creating = !state.isSetUp
        val bioOk = Bio.available(ctx)
        AlertDialog(
            onDismissRequest = { showPin = false },
            title = { Text(if (creating) "Criar PIN dos jogos ocultos" else "Jogos ocultos") },
            text = {
                Column {
                    if (creating) Text("Escolha um PIN de 4 a 6 números. Sem ele ninguém vê os jogos ocultos.", fontSize = 13.sp)
                    OutlinedTextField(
                        value = pin,
                        onValueChange = { pin = it.filter { c -> c.isDigit() }.take(6); error = false },
                        singleLine = true,
                        label = { Text("PIN") },
                        isError = error,
                        visualTransformation = PasswordVisualTransformation(),
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword)
                    )
                    if (error) Text(
                        if (creating) "Use de 4 a 6 números." else "PIN incorreto.",
                        color = Color(0xFFF87171), fontSize = 12.sp
                    )
                    if (bioOk && (creating || state.bioEnabled)) {
                        TextButton(onClick = {
                            showPin = false
                            Bio.prompt(activity, "Jogos ocultos", "Cancelar", onSuccess = {
                                if (creating) state.setBio(true)
                                state.unlockWithBio()
                            })
                        }) { Text(if (creating) "Usar só a digital (sem PIN)" else "Usar digital") }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    val ok = if (creating) state.setPin(pin) else state.unlock(pin)
                    if (ok) showPin = false else error = true
                }) { Text(if (creating) "Criar" else "Entrar") }
            },
            dismissButton = { TextButton(onClick = { showPin = false }) { Text("Cancelar") } }
        )
    }
}

object IconCache {
    private val cache = android.util.LruCache<String, ImageBitmap>(80)
    fun get(key: String): ImageBitmap? = cache.get(key)
    fun put(key: String, value: ImageBitmap) {
        cache.put(key, value)
    }
}

@Composable
fun GameCard(app: AppEntry, accent: Color, fr: FocusRequester?, onClick: () -> Unit) {
    val pm = LocalContext.current.packageManager
    val icon by produceState<ImageBitmap?>(IconCache.get(app.pkg), app.pkg) {
        if (value == null) {
            val loaded = withContext(Dispatchers.Default) {
                runCatching { pm.getApplicationIcon(app.pkg).toBitmap(128, 128).asImageBitmap() }.getOrNull()
            }
            if (loaded != null) IconCache.put(app.pkg, loaded)
            value = loaded
        }
    }
    FocusSurface(accent, Modifier.fillMaxWidth().height(170.dp), RoundedCornerShape(20.dp), fr, onClick) {
        Column(
            Modifier.fillMaxSize().padding(12.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            val bmp = icon
            if (bmp != null) {
                Image(bmp, contentDescription = null, modifier = Modifier.size(84.dp))
            } else {
                Box(Modifier.size(84.dp))
            }
            Spacer(Modifier.height(12.dp))
            Text(
                app.label, color = Color.White, fontSize = 14.sp, maxLines = 2,
                overflow = TextOverflow.Ellipsis, textAlign = TextAlign.Center
            )
        }
    }
}

private enum class Page { MAIN, GAMES }

@Composable
fun SettingsScreen(state: LauncherState, accent: Color, close: () -> Unit) {
    val sfx = LocalSfx.current
    val ctx = LocalContext.current
    var page by remember { mutableStateOf(Page.MAIN) }
    var showDialog by remember { mutableStateOf(false) }
    var showPinEdit by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()
    val activity = ctx as? android.app.Activity
    var pickKind by remember { mutableStateOf(BgStore.LAUNCHER) }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) scope.launch { state.setBg(pickKind, uri) }
    }

    BackHandler(true) {
        sfx.back()
        if (page != Page.MAIN) page = Page.MAIN else close()
    }

    Column(
        Modifier
            .fillMaxSize()
            .systemBarsPadding()
            .padding(horizontal = 28.dp, vertical = 16.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            FocusSurface(
                accent, Modifier.size(44.dp), CircleShape,
                onClick = { if (page != Page.MAIN) page = Page.MAIN else close() }
            ) {
                Text("←", color = Color.White, fontSize = 22.sp, modifier = Modifier.align(Alignment.Center))
            }
            Spacer(Modifier.width(14.dp))
            Text(
                when (page) {
                    Page.MAIN -> "Configurações"
                    Page.GAMES -> "Gerenciar jogos"
                },
                color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold
            )
        }
        Spacer(Modifier.height(12.dp))

        if (page == Page.GAMES) {
            Text(
                "Marque o que aparece na tela inicial deste perfil.",
                color = Color(0xFF9AA4B2), fontSize = 13.sp
            )
            LazyColumn(
                verticalArrangement = Arrangement.spacedBy(10.dp),
                contentPadding = PaddingValues(vertical = 14.dp, horizontal = 8.dp),
                modifier = Modifier.weight(1f)
            ) {
                if (state.unlocked) item(key = "security") {
                    val bioOk = Bio.available(ctx)
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        SectionTitle("Segurança dos jogos ocultos")
                        FocusSurface(accent, Modifier.fillMaxWidth(), onClick = {
                            when {
                                !bioOk -> android.widget.Toast.makeText(ctx, "Este aparelho não tem digital cadastrada", android.widget.Toast.LENGTH_SHORT).show()
                                state.bioEnabled && !state.hasPin -> android.widget.Toast.makeText(ctx, "Crie um PIN antes de desligar a digital", android.widget.Toast.LENGTH_SHORT).show()
                                state.bioEnabled -> state.setBio(false)
                                else -> Bio.prompt(activity, "Ativar digital", "Cancelar", onSuccess = { state.setBio(true) })
                            }
                        }) {
                            Row(Modifier.padding(16.dp, 12.dp), verticalAlignment = Alignment.CenterVertically) {
                                Column(Modifier.weight(1f)) {
                                    Text("Desbloquear com digital", color = Color.White, fontSize = 15.sp)
                                    Text(
                                        if (bioOk) "Usa a digital cadastrada no Android" else "Indisponível: cadastre uma digital no Android",
                                        color = Color(0xFF9AA4B2), fontSize = 12.sp
                                    )
                                }
                                Switch(checked = state.bioEnabled, onCheckedChange = null)
                            }
                        }
                        FocusSurface(accent, Modifier.fillMaxWidth(), onClick = { showPinEdit = true }) {
                            Text(
                                if (state.hasPin) "Alterar PIN" else "Criar PIN",
                                color = Color.White, fontSize = 15.sp, modifier = Modifier.padding(16.dp, 12.dp)
                            )
                        }
                        if (state.hasPin && state.bioEnabled) {
                            FocusSurface(accent, Modifier.fillMaxWidth(), onClick = { state.clearPin() }) {
                                Text("Remover PIN (usar só a digital)", color = Color(0xFFF87171), fontSize = 15.sp, modifier = Modifier.padding(16.dp, 12.dp))
                            }
                        }
                        SectionTitle("Jogos")
                    }
                }
                items(state.manageable, key = { it.pkg }) { app ->
                    val visible = state.isVisible(app)
                    val isSecret = app.pkg in state.secret
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        FocusSurface(accent, Modifier.weight(1f), onClick = { state.toggle(app) }) {
                            Row(Modifier.padding(16.dp, 12.dp), verticalAlignment = Alignment.CenterVertically) {
                                Column(Modifier.weight(1f)) {
                                    Text(app.label, color = Color.White, fontSize = 15.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                    if (app.isGame) Text("Detectado como jogo", color = Color(0xFF7C8798), fontSize = 11.sp)
                                }
                                Text(
                                    if (visible) "✓ Visível" else "Oculto",
                                    color = if (visible) accent else Color(0xFF7C8798), fontSize = 13.sp
                                )
                            }
                        }
                        // o botão de secreto só existe depois de digitar o PIN
                        if (state.unlocked) {
                            Spacer(Modifier.width(8.dp))
                            FocusSurface(accent, Modifier.size(52.dp), onClick = { state.toggleSecret(app) }) {
                                Text(
                                    if (isSecret) "🔒" else "🔓",
                                    fontSize = 20.sp, modifier = Modifier.align(Alignment.Center)
                                )
                            }
                        }
                    }
                }
            }
        } else {
            Column(
                Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(horizontal = 8.dp, vertical = 6.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                SectionTitle("Perfil")
                state.profiles.forEach { p ->
                    FocusSurface(accent, Modifier.fillMaxWidth(), onClick = { state.switchTo(p) }) {
                        Row(Modifier.padding(16.dp, 12.dp), verticalAlignment = Alignment.CenterVertically) {
                            Text(p, color = Color.White, fontSize = 15.sp, modifier = Modifier.weight(1f))
                            if (p == state.current) Text("✓ Ativo", color = accent, fontSize = 13.sp)
                        }
                    }
                }
                FocusSurface(accent, Modifier.fillMaxWidth(), onClick = { showDialog = true }) {
                    Text("＋ Novo perfil", color = Color.White, fontSize = 15.sp, modifier = Modifier.padding(16.dp, 12.dp))
                }
                if (state.profiles.size > 1) {
                    FocusSurface(accent, Modifier.fillMaxWidth(), onClick = { state.deleteProfile(state.current) }) {
                        Text(
                            "Excluir perfil “${state.current}”",
                            color = Color(0xFFF87171), fontSize = 15.sp, modifier = Modifier.padding(16.dp, 12.dp)
                        )
                    }
                }

                SectionTitle("Modo de desempenho")
                PerfMode.values().forEach { m ->
                    FocusSurface(accent, Modifier.fillMaxWidth(), onClick = { state.changeMode(m) }) {
                        Row(Modifier.padding(16.dp, 12.dp), verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text(m.label, color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
                                Text(m.desc, color = Color(0xFF9AA4B2), fontSize = 12.sp)
                            }
                            if (m == state.mode) Text("✓", color = accent, fontSize = 18.sp)
                        }
                    }
                }

                SectionTitle("Cor de destaque (launcher e painel do jogo)")
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.padding(vertical = 6.dp)) {
                    Accents.forEach { c ->
                        val selected = c.toArgb() == state.accentColor
                        FocusSurface(c, Modifier.size(40.dp), CircleShape, onClick = { state.chooseAccent(c.toArgb()) }) {
                            Box(
                                Modifier
                                    .fillMaxSize()
                                    .padding(if (selected) 5.dp else 10.dp)
                                    .background(c, CircleShape)
                            )
                        }
                    }
                }
                var hue by remember(state.accentColor) {
                    mutableFloatStateOf(FloatArray(3).also { android.graphics.Color.colorToHSV(state.accentColor, it) }[0])
                }
                Text("Personalizada", color = Color(0xFF9AA4B2), fontSize = 12.sp)
                Slider(
                    value = hue,
                    onValueChange = { hue = it },
                    onValueChangeFinished = {
                        state.chooseAccent(android.graphics.Color.HSVToColor(floatArrayOf(hue, 0.78f, 1f)))
                    },
                    valueRange = 0f..359f,
                    colors = SliderDefaults.colors(thumbColor = accent, activeTrackColor = accent)
                )

                SectionTitle("Sons")
                FocusSurface(accent, Modifier.fillMaxWidth(), onClick = { state.changeSound(!state.sound) }) {
                    Row(Modifier.padding(16.dp, 12.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text("Sons de navegação", color = Color.White, fontSize = 15.sp, modifier = Modifier.weight(1f))
                        Switch(checked = state.sound, onCheckedChange = null)
                    }
                }

                SectionTitle("Durante o jogo")
                FocusSurface(accent, Modifier.fillMaxWidth(), onClick = {
                    val on = !state.overlay
                    state.changeOverlay(on)
                    if (on && !Perms.hasOverlay(ctx)) Perms.askOverlay(ctx)
                }) {
                    Row(Modifier.padding(16.dp, 12.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("Painel de desempenho", color = Color.White, fontSize = 15.sp)
                            Text(
                                "Mostra Hz, CPU, temperatura, RAM e bateria sobre o jogo",
                                color = Color(0xFF9AA4B2), fontSize = 12.sp
                            )
                        }
                        Switch(checked = state.overlay, onCheckedChange = null)
                    }
                }
                FocusSurface(accent, Modifier.fillMaxWidth(), onClick = {
                    val on = !state.dnd
                    state.changeDnd(on)
                    if (on && !Dnd.hasAccess(ctx)) Perms.askDnd(ctx)
                }) {
                    Row(Modifier.padding(16.dp, 12.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("Não perturbar ao jogar", color = Color.White, fontSize = 15.sp)
                            Text(
                                "Silencia notificações enquanto o jogo está aberto",
                                color = Color(0xFF9AA4B2), fontSize = 12.sp
                            )
                        }
                        Switch(checked = state.dnd, onCheckedChange = null)
                    }
                }

                SectionTitle("Foto de fundo")
                listOf(
                    BgStore.LAUNCHER to ("Launcher" to state.bgLauncher),
                    BgStore.PANEL to ("Painel durante o jogo" to state.bgPanel)
                ).forEach { (kind, info) ->
                    val (title, path) = info
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        FocusSurface(accent, Modifier.weight(1f), onClick = {
                            pickKind = kind
                            picker.launch("image/*")
                        }) {
                            Row(Modifier.padding(16.dp, 12.dp), verticalAlignment = Alignment.CenterVertically) {
                                Column(Modifier.weight(1f)) {
                                    Text(title, color = Color.White, fontSize = 15.sp)
                                    Text(
                                        if (path != null) "✓ Foto definida · toque para trocar" else "Toque para escolher uma foto",
                                        color = Color(0xFF9AA4B2), fontSize = 12.sp
                                    )
                                }
                            }
                        }
                        if (path != null) {
                            Spacer(Modifier.width(8.dp))
                            FocusSurface(accent, Modifier.size(52.dp), onClick = { state.clearBg(kind) }) {
                                Text("✕", color = Color(0xFFF87171), fontSize = 18.sp, modifier = Modifier.align(Alignment.Center))
                            }
                        }
                    }
                }

                SectionTitle("Jogos")
                FocusSurface(accent, Modifier.fillMaxWidth(), onClick = { page = Page.GAMES }) {
                    Text("Gerenciar jogos exibidos", color = Color.White, fontSize = 15.sp, modifier = Modifier.padding(16.dp, 12.dp))
                }
                Spacer(Modifier.height(24.dp))
            }
        }
    }

    if (showPinEdit) {
        var pin by remember { mutableStateOf("") }
        var bad by remember { mutableStateOf(false) }
        AlertDialog(
            onDismissRequest = { showPinEdit = false },
            title = { Text(if (state.hasPin) "Novo PIN" else "Criar PIN") },
            text = {
                Column {
                    OutlinedTextField(
                        value = pin,
                        onValueChange = { pin = it.filter { c -> c.isDigit() }.take(6); bad = false },
                        singleLine = true,
                        label = { Text("4 a 6 números") },
                        isError = bad,
                        visualTransformation = PasswordVisualTransformation(),
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword)
                    )
                    if (bad) Text("Use de 4 a 6 números.", color = Color(0xFFF87171), fontSize = 12.sp)
                }
            },
            confirmButton = {
                TextButton(onClick = { if (state.setPin(pin)) showPinEdit = false else bad = true }) { Text("Salvar") }
            },
            dismissButton = { TextButton(onClick = { showPinEdit = false }) { Text("Cancelar") } }
        )
    }

    if (showDialog) {
        var name by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { showDialog = false },
            title = { Text("Novo perfil") },
            text = {
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it.take(16) },
                    singleLine = true,
                    label = { Text("Nome") }
                )
            },
            confirmButton = {
                TextButton(onClick = { state.createProfile(name); showDialog = false }) { Text("Criar") }
            },
            dismissButton = {
                TextButton(onClick = { showDialog = false }) { Text("Cancelar") }
            }
        )
    }
}

@Composable
private fun SectionTitle(text: String) {
    Text(
        text.uppercase(), color = Color(0xFF7C8798), fontSize = 12.sp,
        fontWeight = FontWeight.Bold, letterSpacing = 2.sp,
        modifier = Modifier.padding(top = 14.dp, bottom = 2.dp)
    )
}
