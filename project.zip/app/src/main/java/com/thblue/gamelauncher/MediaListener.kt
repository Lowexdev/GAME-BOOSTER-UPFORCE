package com.thblue.gamelauncher

import android.service.notification.NotificationListenerService

/** Vazio de propósito: só existir (com o acesso liberado) permite ao painel ler e controlar o player de música. */
class MediaListener : NotificationListenerService()
