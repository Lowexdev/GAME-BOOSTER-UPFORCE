package com.thblue.gamelauncher

import android.accessibilityservice.AccessibilityService
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.provider.Settings
import android.view.Gravity
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.widget.TextView

/**
 * Modo prioridade: abre "Informações do app" de cada app alvo e toca em "Forçar parada".
 * Só age enquanto uma limpeza iniciada pelo launcher está em andamento.
 */
class ForceStopService : AccessibilityService() {
    private val handler = Handler(Looper.getMainLooper())
    private val queue = ArrayDeque<String>()
    private var step = 0
    private var stepStart = 0L
    private var total = 0
    private var done = 0
    private var running = false
    private var finalIntent: Intent? = null
    private var banner: TextView? = null

    private val tick = object : Runnable {
        override fun run() {
            if (!running) return
            val now = SystemClock.uptimeMillis()
            if (now - stepStart > 5000) {
                next()
                return
            }
            val root = rootInActiveWindow
            if (root != null) {
                if (step == 1) {
                    val btn = findForceStop(root)
                    if (btn != null) {
                        if (btn.isEnabled) {
                            if (click(btn)) {
                                step = 2
                                stepStart = now
                            }
                        } else if (now - stepStart > 1500) {
                            next()
                            return
                        }
                    }
                } else if (step == 2) {
                    val ok = findConfirm(root)
                    if (ok != null && click(ok)) {
                        step = 3
                        handler.postDelayed({ next() }, 300)
                        return
                    }
                }
            }
            handler.postDelayed(this, 120)
        }
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}

    override fun onInterrupt() {}

    override fun onUnbind(intent: Intent?): Boolean {
        stopAll()
        instance = null
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        stopAll()
        instance = null
        super.onDestroy()
    }

    /** Fecha os apps da lista e, no fim, abre [thenLaunch] (o jogo). */
    fun start(packages: List<String>, thenLaunch: Intent) {
        if (running) return
        queue.clear()
        queue.addAll(packages)
        total = packages.size
        done = 0
        finalIntent = thenLaunch
        running = true
        showBanner()
        next()
    }

    private fun next() {
        handler.removeCallbacks(tick)
        val pkg = queue.removeFirstOrNull()
        if (pkg == null) {
            complete()
            return
        }
        done++
        updateBanner()
        step = 1
        stepStart = SystemClock.uptimeMillis()
        runCatching {
            startActivity(
                Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$pkg"))
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_NO_ANIMATION)
            )
        }
        handler.postDelayed(tick, 250)
    }

    private fun complete() {
        running = false
        handler.removeCallbacks(tick)
        val i = finalIntent
        finalIntent = null
        if (i != null) runCatching { startActivity(i) }
        handler.postDelayed({ hideBanner() }, 1500)
    }

    private fun stopAll() {
        running = false
        handler.removeCallbacksAndMessages(null)
        hideBanner()
    }

    private fun findForceStop(root: AccessibilityNodeInfo): AccessibilityNodeInfo? {
        for (label in FORCE_LABELS) {
            val l = root.findAccessibilityNodeInfosByText(label)
            if (!l.isNullOrEmpty()) return l[0]
        }
        return null
    }

    private fun findConfirm(root: AccessibilityNodeInfo): AccessibilityNodeInfo? {
        val ids = root.findAccessibilityNodeInfosByViewId("android:id/button1")
        if (!ids.isNullOrEmpty()) return ids[0]
        val ok = root.findAccessibilityNodeInfosByText("OK")
        if (!ok.isNullOrEmpty()) {
            for (n in ok) {
                if (n.text?.toString()?.equals("ok", ignoreCase = true) == true) return n
            }
        }
        return null
    }

    private fun click(n: AccessibilityNodeInfo): Boolean {
        var x: AccessibilityNodeInfo? = n
        var guard = 0
        while (x != null && guard < 6) {
            if (x.isClickable) return x.performAction(AccessibilityNodeInfo.ACTION_CLICK)
            x = x.parent
            guard++
        }
        return false
    }

    private fun showBanner() {
        if (banner != null) return
        val d = resources.displayMetrics.density
        val t = TextView(this)
        t.setTextColor(Color.WHITE)
        t.textSize = 16f
        t.gravity = Gravity.CENTER
        t.setPadding((14 * d).toInt(), (8 * d).toInt(), (14 * d).toInt(), (8 * d).toInt())
        val bg = GradientDrawable()
        bg.setColor(0xFA060A12.toInt())
        t.background = bg
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        runCatching {
            (getSystemService(Context.WINDOW_SERVICE) as WindowManager).addView(t, lp)
            banner = t
        }
        updateBanner()
    }

    private fun updateBanner() {
        banner?.text = "Modo prioridade\n\nFechando apps ($done/$total)…"
    }

    private fun hideBanner() {
        val b = banner ?: return
        runCatching { (getSystemService(Context.WINDOW_SERVICE) as WindowManager).removeView(b) }
        banner = null
    }

    companion object {
        @Volatile
        var instance: ForceStopService? = null

        private val FORCE_LABELS = listOf(
            "Forçar parada", "Forçar encerramento", "Force stop", "Forzar detención", "Forzar parada"
        )

        fun isEnabled(ctx: Context): Boolean {
            val enabled = Settings.Secure.getString(
                ctx.contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
            ) ?: return false
            val cn = ComponentName(ctx, ForceStopService::class.java)
            return enabled.contains(cn.flattenToString()) || enabled.contains(cn.flattenToShortString())
        }
    }
}
