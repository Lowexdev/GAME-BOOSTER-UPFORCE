package com.thblue.gamelauncher

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.widget.Toast
import rikka.shizuku.Shizuku

/** Fecha apps de uma vez via Shizuku (shell com permissão de ADB), como o Hibernator. */
object ShizukuHelper {
    private const val REQUEST_CODE = 4242
    private const val SHIZUKU_PKG = "moe.shizuku.privileged.api"

    fun available(): Boolean = runCatching { Shizuku.pingBinder() }.getOrDefault(false)

    fun granted(): Boolean = runCatching {
        Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
    }.getOrDefault(false)

    fun requestPermission() {
        runCatching { Shizuku.requestPermission(REQUEST_CODE) }
    }

    /** Roda `am force-stop` para todos os pacotes em um único comando. Chamar fora da thread principal. */
    fun forceStop(pkgs: List<String>): Boolean {
        if (pkgs.isEmpty()) return true
        return runCatching {
            val cmd = pkgs.joinToString("; ") { "am force-stop $it" }
            val m = Shizuku::class.java.getDeclaredMethod(
                "newProcess",
                Array<String>::class.java,
                Array<String>::class.java,
                String::class.java
            )
            m.isAccessible = true
            val p = m.invoke(null, arrayOf("sh", "-c", cmd), null, null) as Process
            p.waitFor()
            true
        }.getOrDefault(false)
    }

    /** Leva o usuário ao passo que falta: pedir permissão, abrir o Shizuku ou baixar. */
    fun setup(ctx: Context) {
        if (available()) {
            if (!granted()) {
                requestPermission()
            } else {
                Toast.makeText(ctx, "Shizuku já está pronto", Toast.LENGTH_SHORT).show()
            }
            return
        }
        val launch = ctx.packageManager.getLaunchIntentForPackage(SHIZUKU_PKG)
        if (launch != null) {
            Toast.makeText(ctx, "Inicie o Shizuku (Depuração sem fio) e volte aqui", Toast.LENGTH_LONG).show()
            ctx.startActivity(launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        } else {
            ctx.startActivity(
                Intent(Intent.ACTION_VIEW, Uri.parse("https://shizuku.rikka.app/download/"))
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            )
        }
    }
}
