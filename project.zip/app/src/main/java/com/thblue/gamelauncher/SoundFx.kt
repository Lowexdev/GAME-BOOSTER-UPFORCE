package com.thblue.gamelauncher

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import android.os.Handler
import android.os.Looper
import java.util.concurrent.Executors
import kotlin.math.PI
import kotlin.math.exp
import kotlin.math.sin

/** Sons de interface gerados por código (sem arquivos), no estilo dos menus de console. */
class SoundFx {
    @Volatile
    var enabled = true

    private val rate = 44100
    private val io = Executors.newSingleThreadExecutor()
    private val main = Handler(Looper.getMainLooper())
    private var lastMove = 0L

    private class Note(
        val freq: Double,
        val startMs: Int,
        val lenMs: Int,
        val gain: Double = 1.0,
        val decay: Double = 8.0,
        val swell: Boolean = false
    )

    private fun synth(totalMs: Int, notes: List<Note>, volume: Double): ShortArray {
        val n = rate * totalMs / 1000
        val buf = DoubleArray(n)
        for (note in notes) {
            val s = rate * note.startMs / 1000
            val l = rate * note.lenMs / 1000
            for (i in 0 until l) {
                val idx = s + i
                if (idx >= n) break
                val t = i.toDouble() / rate
                val env = if (note.swell) {
                    val x = sin(PI * i / l)
                    x * x
                } else {
                    minOf(1.0, i / (rate * 0.006)) * exp(-note.decay * t)
                }
                val w = sin(2 * PI * note.freq * t) +
                    0.3 * sin(2 * PI * note.freq * 2 * t) +
                    0.1 * sin(2 * PI * note.freq * 3 * t)
                buf[idx] += w * env * note.gain
            }
        }
        val out = ShortArray(n)
        for (i in 0 until n) {
            out[i] = (buf[i].coerceIn(-1.0, 1.0) * volume * Short.MAX_VALUE).toInt().toShort()
        }
        return out
    }

    private val moveP by lazy {
        synth(100, listOf(Note(880.0, 0, 90, 0.8, 45.0), Note(1320.0, 0, 90, 0.4, 45.0)), 0.35)
    }
    private val selectP by lazy {
        synth(
            420,
            listOf(
                Note(659.0, 0, 200, 1.0, 16.0),
                Note(988.0, 70, 340, 0.9, 11.0),
                Note(1319.0, 70, 340, 0.35, 11.0)
            ),
            0.45
        )
    }
    private val backP by lazy {
        synth(300, listOf(Note(988.0, 0, 150, 0.9, 18.0), Note(659.0, 70, 220, 0.9, 14.0)), 0.4)
    }
    private val launchP by lazy {
        synth(
            600,
            listOf(
                Note(523.0, 0, 250, 1.0, 10.0),
                Note(784.0, 90, 300, 0.9, 9.0),
                Note(1047.0, 180, 400, 0.9, 8.0)
            ),
            0.45
        )
    }
    private val bootP by lazy {
        synth(
            2800,
            listOf(
                Note(261.6, 0, 2600, 0.6, swell = true),
                Note(392.0, 150, 2500, 0.5, swell = true),
                Note(659.3, 300, 2400, 0.4, swell = true),
                Note(987.8, 450, 2300, 0.3, swell = true)
            ),
            0.4
        )
    }

    private fun play(pcm: ShortArray) {
        if (!enabled) return
        io.execute {
            runCatching {
                val track = AudioTrack.Builder()
                    .setAudioAttributes(
                        AudioAttributes.Builder()
                            .setUsage(AudioAttributes.USAGE_GAME)
                            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                            .build()
                    )
                    .setAudioFormat(
                        AudioFormat.Builder()
                            .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                            .setSampleRate(rate)
                            .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                            .build()
                    )
                    .setBufferSizeInBytes(pcm.size * 2)
                    .setTransferMode(AudioTrack.MODE_STATIC)
                    .build()
                track.write(pcm, 0, pcm.size)
                track.play()
                val ms = pcm.size * 1000L / rate + 150
                main.postDelayed({ runCatching { track.release() } }, ms)
            }
        }
    }

    fun move() {
        val now = System.currentTimeMillis()
        if (now - lastMove < 45) return
        lastMove = now
        play(moveP)
    }

    fun select() = play(selectP)
    fun back() = play(backP)
    fun launch() = play(launchP)
    fun boot() = play(bootP)
}
