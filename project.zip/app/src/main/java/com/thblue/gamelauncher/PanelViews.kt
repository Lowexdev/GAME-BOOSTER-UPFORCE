package com.thblue.gamelauncher

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.ColorFilter
import android.graphics.DashPathEffect
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.drawable.Drawable
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.widget.FrameLayout
import android.widget.ScrollView
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/** Moldura estilo "game": cantos cortados em diagonal, borda fina e detalhe brilhante nos cortes. */
class CutDrawable(
    private val fillTop: Int,
    private val fillBottom: Int,
    private val stroke: Int,
    private val trim: Int,
    private val cut: Float,
    private val strokeW: Float,
    private val corners: Int
) : Drawable() {
    private val fillPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val strokePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; strokeWidth = strokeW; color = stroke
    }
    private val trimPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; strokeWidth = strokeW * 2.2f; color = trim
        strokeCap = Paint.Cap.ROUND
    }
    private val glowPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; strokeWidth = strokeW * 5f
        color = Color.argb(70, Color.red(trim), Color.green(trim), Color.blue(trim))
        strokeCap = Paint.Cap.ROUND
    }
    private val path = Path()
    private val cuts = ArrayList<FloatArray>()

    override fun onBoundsChange(b: Rect) {
        val h = strokeW / 2f
        val l = b.left + h; val t = b.top + h; val r = b.right - h; val bt = b.bottom - h
        val c = min(cut, min(r - l, bt - t) / 2.5f)
        val tl = corners and TL != 0; val tr = corners and TR != 0
        val br = corners and BR != 0; val bl = corners and BL != 0
        cuts.clear()
        path.reset()
        if (tl) path.moveTo(l + c, t) else path.moveTo(l, t)
        path.lineTo(if (tr) r - c else r, t)
        if (tr) { path.lineTo(r, t + c); cuts.add(floatArrayOf(r - c, t, r, t + c)) }
        path.lineTo(r, if (br) bt - c else bt)
        if (br) { path.lineTo(r - c, bt); cuts.add(floatArrayOf(r, bt - c, r - c, bt)) }
        path.lineTo(if (bl) l + c else l, bt)
        if (bl) { path.lineTo(l, bt - c); cuts.add(floatArrayOf(l + c, bt, l, bt - c)) }
        path.lineTo(l, if (tl) t + c else t)
        if (tl) cuts.add(floatArrayOf(l, t + c, l + c, t))
        path.close()
        fillPaint.shader = LinearGradient(
            0f, b.top.toFloat(), 0f, b.bottom.toFloat(), fillTop, fillBottom, Shader.TileMode.CLAMP
        )
    }

    override fun draw(canvas: Canvas) {
        canvas.drawPath(path, fillPaint)
        canvas.drawPath(path, strokePaint)
        for (s in cuts) {
            canvas.drawLine(s[0], s[1], s[2], s[3], glowPaint)
            canvas.drawLine(s[0], s[1], s[2], s[3], trimPaint)
        }
    }

    override fun setAlpha(alpha: Int) {}
    override fun setColorFilter(cf: ColorFilter?) {}
    @Suppress("OVERRIDE_DEPRECATION")
    override fun getOpacity(): Int = PixelFormat.TRANSLUCENT

    companion object {
        const val TL = 1
        const val TR = 2
        const val BR = 4
        const val BL = 8
    }
}

/** Gráfico de área com linha brilhante. Valores entre 0 e 1. */
class GraphView(ctx: Context, private val accent: Int) : View(ctx) {
    private val data = ArrayList<Float>()
    private val d = ctx.resources.displayMetrics.density
    private val line = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; strokeWidth = 2f * d; color = accent
        strokeJoin = Paint.Join.ROUND; strokeCap = Paint.Cap.ROUND
    }
    private val glow = Paint(line).apply {
        strokeWidth = 6f * d
        color = Color.argb(60, Color.red(accent), Color.green(accent), Color.blue(accent))
    }
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val grid = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; strokeWidth = 1f * d; color = 0x33FFFFFF
        pathEffect = DashPathEffect(floatArrayOf(4f * d, 4f * d), 0f)
    }
    private val label = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0x99AEB9CC.toInt(); textSize = 9f * d; textAlign = Paint.Align.RIGHT
    }
    private val dot = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE }
    private val linePath = Path()
    private val areaPath = Path()

    fun setData(values: List<Float>) {
        data.clear(); data.addAll(values); invalidate()
    }

    override fun onDraw(c: Canvas) {
        val padL = 24f * d; val padT = 6f * d; val padB = 6f * d; val padR = 6f * d
        val r = RectF(padL, padT, width - padR, height - padB)
        for ((i, t) in listOf("100", "50", "0").withIndex()) {
            val y = r.top + r.height() * i / 2f
            c.drawLine(r.left, y, r.right, y, grid)
            c.drawText(t, r.left - 5f * d, y + 3f * d, label)
        }
        val n = data.size
        if (n < 2) return
        val step = r.width() / (MAX - 1)
        val x0 = r.right - (n - 1) * step
        fun px(i: Int) = x0 + i * step
        fun py(v: Float) = r.bottom - r.height() * v.coerceIn(0f, 1f)
        linePath.reset()
        linePath.moveTo(px(0), py(data[0]))
        for (i in 1 until n) {
            val mx = (px(i - 1) + px(i)) / 2f
            linePath.cubicTo(mx, py(data[i - 1]), mx, py(data[i]), px(i), py(data[i]))
        }
        areaPath.set(linePath)
        areaPath.lineTo(px(n - 1), r.bottom)
        areaPath.lineTo(px(0), r.bottom)
        areaPath.close()
        fill.shader = LinearGradient(
            0f, r.top, 0f, r.bottom,
            Color.argb(150, Color.red(accent), Color.green(accent), Color.blue(accent)),
            Color.argb(8, Color.red(accent), Color.green(accent), Color.blue(accent)),
            Shader.TileMode.CLAMP
        )
        c.drawPath(areaPath, fill)
        c.drawPath(linePath, glow)
        c.drawPath(linePath, line)
        c.drawCircle(px(n - 1), py(data[n - 1]), 3.2f * d, dot)
    }

    companion object {
        const val MAX = 45
    }
}

/** Barra de matiz (arco-íris) para escolher uma cor personalizada. */
class HueBar(ctx: Context, startColor: Int, private val onPick: (Int) -> Unit) : View(ctx) {
    private val d = ctx.resources.displayMetrics.density
    private var hue = FloatArray(3).also { Color.colorToHSV(startColor, it) }[0]
    private val track = Paint(Paint.ANTI_ALIAS_FLAG)
    private val thumb = Paint(Paint.ANTI_ALIAS_FLAG)
    private val ring = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; strokeWidth = 2.5f * d; color = Color.WHITE
    }
    private val pad = 12f * d

    private fun colorOf(h: Float) = Color.HSVToColor(floatArrayOf(h, 0.78f, 1f))

    override fun onDraw(c: Canvas) {
        val cy = height / 2f
        val th = 8f * d
        val colors = IntArray(7) { colorOf(it * 60f) }
        track.shader = LinearGradient(pad, 0f, width - pad, 0f, colors, null, Shader.TileMode.CLAMP)
        c.drawRoundRect(pad, cy - th / 2, width - pad, cy + th / 2, th / 2, th / 2, track)
        val x = pad + hue / 360f * (width - 2 * pad)
        thumb.color = colorOf(hue)
        c.drawCircle(x, cy, 9f * d, thumb)
        c.drawCircle(x, cy, 9f * d, ring)
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN, MotionEvent.ACTION_MOVE -> {
                parent?.requestDisallowInterceptTouchEvent(true)
                hue = ((e.x - pad) / (width - 2 * pad)).coerceIn(0f, 1f) * 359f
                invalidate()
            }
            MotionEvent.ACTION_UP -> onPick(colorOf(hue))
        }
        return true
    }
}

/** Aba que fica colada na borda da tela. Toque ou puxe para dentro para abrir o painel. */
class HandleView(ctx: Context, private val accent: Int, private val right: Boolean) : View(ctx) {
    var onOpen: (() -> Unit)? = null
    private val d = ctx.resources.displayMetrics.density
    private val tabW = 15f * d
    private val body = Paint(Paint.ANTI_ALIAS_FLAG)
    private val edge = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; strokeWidth = 1.2f * d; color = 0x66FFFFFF
    }
    private val glow = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; strokeWidth = 5f * d
        color = Color.argb(90, Color.red(accent), Color.green(accent), Color.blue(accent))
    }
    private val chev = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; strokeWidth = 2f * d; color = Color.WHITE
        strokeCap = Paint.Cap.ROUND; strokeJoin = Paint.Join.ROUND
    }
    private val path = Path()
    private val chevPath = Path()
    private var downX = 0f
    private var downY = 0f
    private var fired = false
    private val slop = ViewConfiguration.get(ctx).scaledTouchSlop
    private val fadeRunnable = Runnable { animate().alpha(0.55f).setDuration(400).start() }

    init {
        alpha = 1f
        postDelayed(fadeRunnable, 3000)
    }

    override fun onDraw(c: Canvas) {
        val h = height.toFloat()
        val r = 8f * d
        val left = if (right) width - tabW else 0f
        val rect = RectF(left, 0f, left + tabW, h)
        path.reset()
        val radii = if (right) floatArrayOf(r, r, 0f, 0f, 0f, 0f, r, r) else floatArrayOf(0f, 0f, r, r, r, r, 0f, 0f)
        path.addRoundRect(rect, radii, Path.Direction.CW)
        body.shader = LinearGradient(
            0f, 0f, 0f, h,
            Color.argb(235, min(255, Color.red(accent) + 40), min(255, Color.green(accent) + 40), min(255, Color.blue(accent) + 40)),
            Color.argb(235, Color.red(accent) * 3 / 4, Color.green(accent) * 3 / 4, Color.blue(accent) * 3 / 4),
            Shader.TileMode.CLAMP
        )
        c.drawPath(path, glow)
        c.drawPath(path, body)
        c.drawPath(path, edge)
        // seta apontando para dentro da tela
        val cx = left + tabW / 2f
        val cy = h / 2f
        val s = 4f * d
        val dir = if (right) -1f else 1f
        chevPath.reset()
        chevPath.moveTo(cx - dir * s / 2, cy - s * 1.2f)
        chevPath.lineTo(cx + dir * s / 2, cy)
        chevPath.lineTo(cx - dir * s / 2, cy + s * 1.2f)
        c.drawPath(chevPath, chev)
    }

    private fun fire() {
        if (fired) return
        fired = true
        performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY)
        onOpen?.invoke()
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                downX = e.rawX; downY = e.rawY; fired = false
                removeCallbacks(fadeRunnable); animate().cancel(); alpha = 1f
            }
            MotionEvent.ACTION_MOVE -> {
                val inward = (e.rawX - downX) * (if (right) -1f else 1f)
                if (inward > 10f * d) fire()
            }
            MotionEvent.ACTION_UP -> {
                if (!fired && abs(e.rawX - downX) < slop * 2 && abs(e.rawY - downY) < slop * 2) fire()
                postDelayed(fadeRunnable, 3000)
            }
            MotionEvent.ACTION_CANCEL -> postDelayed(fadeRunnable, 3000)
        }
        return true
    }

    fun wake() {
        removeCallbacks(fadeRunnable); animate().cancel(); alpha = 1f
        postDelayed(fadeRunnable, 3000)
    }
}

/** Raiz do painel: arrastar em direção à borda fecha; toque fora também (ACTION_OUTSIDE). */
class SwipeCloseLayout(
    ctx: Context,
    private val dir: Int, // -1 = painel na esquerda (fecha indo para a esquerda), +1 = direita
    private val onClose: () -> Unit
) : FrameLayout(ctx) {
    private var downX = 0f
    private var downY = 0f
    private var dragging = false
    private val slop = ViewConfiguration.get(ctx).scaledTouchSlop

    override fun onInterceptTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> { downX = e.rawX; downY = e.rawY; dragging = false }
            MotionEvent.ACTION_MOVE -> {
                val toward = (e.rawX - downX) * dir
                if (!dragging && toward > slop * 2 && toward > abs(e.rawY - downY)) {
                    dragging = true
                    return true
                }
            }
        }
        return false
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_OUTSIDE -> { onClose(); return true }
            MotionEvent.ACTION_DOWN -> { downX = e.rawX; downY = e.rawY; return true }
            MotionEvent.ACTION_MOVE -> if (dragging) {
                val d = e.rawX - downX
                translationX = if (dir < 0) min(0f, d) else max(0f, d)
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> if (dragging) {
                dragging = false
                if (abs(translationX) > width * 0.28f) onClose()
                else animate().translationX(0f).setDuration(160).start()
            }
        }
        return true
    }
}

/** ScrollView que não passa de uma altura máxima (o painel nunca estoura a tela). */
class MaxHeightScroll(ctx: Context, private val maxPx: Int) : ScrollView(ctx) {
    override fun onMeasure(w: Int, h: Int) {
        super.onMeasure(w, MeasureSpec.makeMeasureSpec(maxPx, MeasureSpec.AT_MOST))
    }
}
