package com.thblue.gamelauncher

import android.app.NotificationManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.Settings

object Perms {
    fun hasOverlay(ctx: Context): Boolean = Settings.canDrawOverlays(ctx)

    fun askOverlay(ctx: Context) {
        ctx.startActivity(
            Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:${ctx.packageName}"))
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        )
    }

    fun askDnd(ctx: Context) {
        ctx.startActivity(
            Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        )
    }
}

/** Liga o "Não perturbe" (só prioridade) ao abrir o jogo e restaura o estado anterior ao voltar. */
object Dnd {
    private const val KEY = "dnd_prev"

    fun hasAccess(ctx: Context): Boolean {
        val nm = ctx.getSystemService(NotificationManager::class.java)
        return nm.isNotificationPolicyAccessGranted
    }

    fun enable(ctx: Context) {
        val nm = ctx.getSystemService(NotificationManager::class.java)
        if (!nm.isNotificationPolicyAccessGranted) return
        val sp = ctx.getSharedPreferences("launcher", Context.MODE_PRIVATE)
        if (sp.getInt(KEY, -1) == -1) {
            sp.edit().putInt(KEY, nm.currentInterruptionFilter).apply()
        }
        nm.setInterruptionFilter(NotificationManager.INTERRUPTION_FILTER_PRIORITY)
    }

    fun restore(ctx: Context) {
        val sp = ctx.getSharedPreferences("launcher", Context.MODE_PRIVATE)
        val prev = sp.getInt(KEY, -1)
        if (prev == -1) return
        val nm = ctx.getSystemService(NotificationManager::class.java)
        if (nm.isNotificationPolicyAccessGranted) {
            val filter = if (prev in 1..4) prev else NotificationManager.INTERRUPTION_FILTER_ALL
            nm.setInterruptionFilter(filter)
        }
        sp.edit().remove(KEY).apply()
    }
}
