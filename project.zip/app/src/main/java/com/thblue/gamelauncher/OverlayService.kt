package com.thblue.gamelauncher

import android.app.ActivityManager
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Rect
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.hardware.display.DisplayManager
import android.os.BatteryManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.SystemClock
import android.text.SpannableStringBuilder
import android.text.Spanned
import android.text.style.RelativeSizeSpan
import android.util.TypedValue
import android.view.Display
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.view.animation.AccelerateInterpolator
import android.view.animation.DecelerateInterpolator
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import java.io.File

/**
 * Painel de jogo: uma aba fica na borda da tela; puxe (ou toque) para o painel deslizar.
 * Mostra gráfico ao vivo, Hz, CPU, temperatura, RAM, bateria, atalhos e a cor do painel.
 */
class OverlayService : Service() {
    private lateinit var wm: WindowManager
    private val handler = Handler(Looper.getMainLooper())
    private val density get() = resources.displayMetrics.density

    private var handleView: HandleView? = null
    private var panel: SwipeCloseLayout? = null
    private var closing = false
    private var colorsOpen = false

    private var accent = AccentStore.DEFAULT
    private var right = false
    private var gamePkg: String? = null
    private var sessionStart = SystemClock.elapsedRealtime()
    private val history = ArrayList<Float>()
    private var usingCpu = true
    private val cpuTempPath: String? by lazy { findCpuTempPath() }

    // Referências para atualizar a cada segundo.
    private var graph: GraphView? = null
    private var graphTitle: TextView? = null
    private var hzBig: TextView? = null
    private var cpuBig: TextView? = null
    private var cpuLabel: TextView? = null
    private var tempText: TextView? = null
    private var ramText: TextView? = null
    private var batText: TextView? = null
    private var timerText: TextView? = null

    private val tick = object : Runnable {
        override fun run() {
            update()
            handler.postDelayed(this, 1000)
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startAsForeground()
        intent?.getStringExtra(EXTRA_GAME)?.let { gamePkg = it }
        if (handleView == null) {
            wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
            accent = AccentStore.read(this)
            right = AccentStore.readRight(this)
            sessionStart = SystemClock.elapsedRealtime()
            showHandle()
        }
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        panel?.let { runCatching { wm.removeView(it) } }
        handleView?.let { runCatching { wm.removeView(it) } }
        panel = null
        handleView = null
        super.onDestroy()
    }

    private fun startAsForeground() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL, "Painel de desempenho", NotificationManager.IMPORTANCE_MIN)
        )
        val n = Notification.Builder(this, CHANNEL)
            .setContentTitle("Painel de desempenho ativo")
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setOngoing(true)
            .build()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(1, n)
        }
    }

    // ---------------------------------------------------------------- helpers

    private fun dp(v: Int) = (v * density).toInt()
    private fun dpf(v: Float) = v * density

    private fun screenSize(): Pair<Int, Int> {
        return if (Build.VERSION.SDK_INT >= 30) {
            val b = wm.currentWindowMetrics.bounds
            b.width() to b.height()
        } else {
            val m = android.util.DisplayMetrics()
            @Suppress("DEPRECATION")
            wm.defaultDisplay.getRealMetrics(m)
            m.widthPixels to m.heightPixels
        }
    }

    private fun alpha(color: Int, a: Int) = Color.argb(a, Color.red(color), Color.green(color), Color.blue(color))

    private fun icon(res: Int, sizeDp: Int, tint: Int): ImageView {
        val v = ImageView(this)
        v.setImageResource(res)
        v.setColorFilter(tint)
        v.layoutParams = LinearLayout.LayoutParams(dp(sizeDp), dp(sizeDp))
        return v
    }

    private fun label(text: String, sp: Float, color: Int, bold: Boolean = false): TextView {
        val t = TextView(this)
        t.text = text
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, sp)
        t.setTextColor(color)
        t.includeFontPadding = false
        t.typeface = Typeface.create("sans-serif-condensed", if (bold) Typeface.BOLD else Typeface.NORMAL)
        return t
    }

    private fun bigText(value: String, unit: String): CharSequence {
        val sb = SpannableStringBuilder(value)
        if (unit.isNotEmpty()) {
            sb.append(" ").append(unit)
            sb.setSpan(RelativeSizeSpan(0.5f), value.length, sb.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        }
        return sb
    }

    /** Efeito de toque: encolhe um pouco enquanto pressionado. */
    private fun pressable(v: View, onClick: () -> Unit) {
        v.setOnTouchListener { view, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> view.animate().scaleX(0.94f).scaleY(0.94f).alpha(0.85f).setDuration(80).start()
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    view.animate().scaleX(1f).scaleY(1f).alpha(1f).setDuration(120).start()
                    if (e.actionMasked == MotionEvent.ACTION_UP &&
                        e.x in 0f..view.width.toFloat() && e.y in 0f..view.height.toFloat()
                    ) {
                        view.performHapticFeedback(android.view.HapticFeedbackConstants.VIRTUAL_KEY)
                        handler.post { onClick() }
                    }
                }
            }
            true
        }
    }

    // ---------------------------------------------------------------- aba na borda

    private fun showHandle() {
        val h = HandleView(this, accent, right)
        h.onOpen = { openPanel() }
        val lp = WindowManager.LayoutParams(
            dp(24), dp(88),
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = (if (right) Gravity.END else Gravity.START) or Gravity.CENTER_VERTICAL
        runCatching { wm.addView(h, lp) }.onSuccess {
            handleView = h
            if (Build.VERSION.SDK_INT >= 29) {
                h.post { h.systemGestureExclusionRects = listOf(Rect(0, 0, h.width, h.height)) }
            }
        }
    }

    private fun rebuildHandle() {
        handleView?.let { runCatching { wm.removeView(it) } }
        handleView = null
        showHandle()
    }

    // ---------------------------------------------------------------- abrir / fechar

    private fun openPanel() {
        if (panel != null || closing) return
        val (sw, sh) = screenSize()
        val p = buildPanel(sw, sh)
        val landscape = sw > sh
        val width = if (landscape) minOf((sw * 0.66f).toInt(), dp(600)) else minOf(sw - dp(12), dp(390))
        val lp = WindowManager.LayoutParams(
            width, WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = (if (right) Gravity.END else Gravity.START) or Gravity.CENTER_VERTICAL
        lp.x = dp(6)
        p.alpha = 0f
        if (runCatching { wm.addView(p, lp) }.isFailure) return
        panel = p
        handleView?.visibility = View.GONE
        p.post {
            val w = p.width.toFloat()
            p.translationX = if (right) w else -w
            p.alpha = 1f
            p.animate().translationX(0f).setDuration(260)
                .setInterpolator(DecelerateInterpolator(1.8f)).start()
        }
        history.clear()
        handler.removeCallbacks(tick)
        handler.post(tick)
    }

    private fun closePanel() {
        val p = panel ?: return
        if (closing) return
        closing = true
        handler.removeCallbacks(tick)
        val w = p.width.toFloat()
        p.animate().translationX(if (right) w else -w).setDuration(200)
            .setInterpolator(AccelerateInterpolator())
            .withEndAction {
                removePanelNow()
                handleView?.let { it.visibility = View.VISIBLE; it.wake() }
                closing = false
            }.start()
    }

    private fun removePanelNow() {
        panel?.let { runCatching { wm.removeView(it) } }
        panel = null
        removeRefs()
    }

    /** Refaz o painel na hora (sem animação), por exemplo depois de trocar a cor. */
    private fun refreshPanelInPlace() {
        val old = panel ?: return
        val lp = old.layoutParams as WindowManager.LayoutParams
        val (sw, sh) = screenSize()
        runCatching { wm.removeView(old) }
        removeRefs()
        val fresh = buildPanel(sw, sh)
        panel = if (runCatching { wm.addView(fresh, lp) }.isSuccess) fresh else null
        update()
    }

    private fun removeRefs() {
        graph = null; graphTitle = null; hzBig = null; cpuBig = null; cpuLabel = null
        tempText = null; ramText = null; batText = null; timerText = null
    }

    private fun setAccent(c: Int) {
        accent = c
        AccentStore.write(this, c)
        rebuildHandle()
        handleView?.visibility = View.GONE
        refreshPanelInPlace()
    }

    // ---------------------------------------------------------------- construção do painel

    private fun buildPanel(sw: Int, sh: Int): SwipeCloseLayout {
        val landscape = sw > sh
        val root = SwipeCloseLayout(this, if (right) 1 else -1) { closePanel() }
        root.background = CutDrawable(
            0xF40A1222.toInt(), 0xF4060B16.toInt(),
            alpha(accent, 200), accent, dpf(18f), dpf(1.4f),
            CutDrawable.TR or CutDrawable.BL
        )
        root.setPadding(dp(4), dp(4), dp(4), dp(4))

        val column = LinearLayout(this)
        column.orientation = LinearLayout.VERTICAL
        column.setPadding(dp(12), dp(8), dp(12), dp(12))

        column.addView(buildHeader())

        val body = LinearLayout(this)
        body.orientation = if (landscape) LinearLayout.HORIZONTAL else LinearLayout.VERTICAL
        val graphCard = buildGraphCard(landscape)
        val tiles = buildTiles()
        if (landscape) {
            body.addView(graphCard, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1.05f))
            body.addView(tiles, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f).apply {
                leftMargin = dp(10)
            })
        } else {
            body.addView(graphCard, LinearLayout.LayoutParams(-1, -2))
            body.addView(tiles, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(10) })
        }
        column.addView(body, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(6) })

        if (colorsOpen) {
            column.addView(buildColorCard(), LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(10) })
        }

        val scroll = MaxHeightScroll(this, sh - dp(40))
        scroll.isVerticalScrollBarEnabled = false
        scroll.overScrollMode = View.OVER_SCROLL_NEVER
        scroll.addView(column)
        root.addView(scroll, android.widget.FrameLayout.LayoutParams(-1, -2))
        return root
    }

    private fun buildHeader(): View {
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL

        val title = label("GAME PANEL", 21f, accent, true)
        title.typeface = Typeface.create("sans-serif-condensed", Typeface.BOLD_ITALIC)
        title.letterSpacing = 0.08f
        title.setShadowLayer(dpf(9f), 0f, 0f, alpha(accent, 220))
        row.addView(title)

        val s = getSharedPreferences("launcher", Context.MODE_PRIVATE)
        val cur = s.getString("current", null)
        val mode = runCatching {
            PerfMode.valueOf(s.getString("p.$cur.mode", null) ?: "PERFORMANCE").label
        }.getOrDefault("Desempenho")
        val chip = label("${cur ?: "Jogador"} · $mode", 12f, 0xFFC9D4E8.toInt(), true)
        chip.gravity = Gravity.END
        chip.maxLines = 1
        chip.ellipsize = android.text.TextUtils.TruncateAt.END
        chip.setPadding(dp(8), 0, dp(8), 0)
        row.addView(chip, LinearLayout.LayoutParams(0, -2, 1f))

        val close = icon(R.drawable.ic_p_close, 18, 0xFFC9D4E8.toInt())
        close.setPadding(dp(7), dp(7), dp(7), dp(7))
        close.layoutParams = LinearLayout.LayoutParams(dp(34), dp(34))
        close.background = CutDrawable(0x22FFFFFF, 0x11FFFFFF, 0x33FFFFFF, accent, dpf(7f), dpf(1f), CutDrawable.BR)
        pressable(close) { closePanel() }
        row.addView(close)
        return row
    }

    private fun buildGraphCard(landscape: Boolean): View {
        val card = LinearLayout(this)
        card.orientation = LinearLayout.VERTICAL
        card.setPadding(dp(10), dp(8), dp(10), dp(10))
        card.background = CutDrawable(
            0x66141F38, 0x66090F1E, alpha(accent, 120), accent, dpf(14f), dpf(1.2f), CutDrawable.TR
        )

        val top = LinearLayout(this)
        top.orientation = LinearLayout.HORIZONTAL
        top.gravity = Gravity.CENTER_VERTICAL
        val title = label(if (usingCpu) "CARGA DA CPU" else "USO DE RAM", 10f, 0xFF9AA8C2.toInt(), true)
        title.letterSpacing = 0.12f
        graphTitle = title
        top.addView(title, LinearLayout.LayoutParams(0, -2, 1f))
        card.addView(top)

        val g = GraphView(this, accent)
        graph = g
        card.addView(g, LinearLayout.LayoutParams(-1, dp(if (landscape) 78 else 92)).apply { topMargin = dp(4) })
        g.setData(history)

        // números grandes: Tela (Hz) e CPU
        val big = LinearLayout(this)
        big.orientation = LinearLayout.HORIZONTAL
        big.addView(bigStat("Tela", true), LinearLayout.LayoutParams(0, -2, 1f))
        big.addView(bigStat("CPU", false), LinearLayout.LayoutParams(0, -2, 1f))
        card.addView(big, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(8) })

        // mini estatísticas
        val mini = LinearLayout(this)
        mini.orientation = LinearLayout.HORIZONTAL
        mini.setPadding(0, dp(8), 0, 0)
        val (m1, t1) = miniStat(R.drawable.ic_p_thermo); tempText = t1
        val (m2, t2) = miniStat(R.drawable.ic_p_ram); ramText = t2
        val (m3, t3) = miniStat(R.drawable.ic_p_battery); batText = t3
        mini.addView(m1, LinearLayout.LayoutParams(0, -2, 1f))
        mini.addView(m2, LinearLayout.LayoutParams(0, -2, 1f))
        mini.addView(m3, LinearLayout.LayoutParams(0, -2, 1f))
        card.addView(mini, LinearLayout.LayoutParams(-1, -2))
        return card
    }

    private fun bigStat(name: String, isHz: Boolean): View {
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        val value = label("--", 26f, Color.WHITE, true)
        value.typeface = Typeface.create("sans-serif-condensed", Typeface.BOLD_ITALIC)
        val sub = LinearLayout(this)
        sub.orientation = LinearLayout.HORIZONTAL
        sub.gravity = Gravity.CENTER_VERTICAL
        val dot = View(this)
        dot.background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(accent) }
        sub.addView(dot, LinearLayout.LayoutParams(dp(6), dp(6)).apply { rightMargin = dp(5) })
        val l = label(name, 11f, 0xFFAFBBD2.toInt())
        sub.addView(l)
        col.addView(value)
        col.addView(sub, LinearLayout.LayoutParams(-2, -2).apply { topMargin = dp(2) })
        if (isHz) hzBig = value else { cpuBig = value; cpuLabel = l }
        return col
    }

    private fun miniStat(res: Int): Pair<View, TextView> {
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        row.addView(icon(res, 17, accent))
        val t = label("--", 12f, Color.WHITE, true)
        t.setPadding(dp(4), 0, 0, 0)
        row.addView(t)
        return row to t
    }

    private fun buildTiles(): View {
        val grid = LinearLayout(this)
        grid.orientation = LinearLayout.VERTICAL

        val dndOn = getSharedPreferences("launcher", Context.MODE_PRIVATE).getInt("dnd_prev", -1) != -1

        val t1 = tile(R.drawable.ic_p_rocket, "Limpar RAM", false) { cleanMemory() }
        val t2 = tile(R.drawable.ic_p_moon, "Não perturbe", dndOn) { toggleDnd() }
        val t3 = tile(R.drawable.ic_p_timer, "00:00", false) {
            sessionStart = SystemClock.elapsedRealtime(); update()
        }
        timerText = t3.getChildAt(1) as TextView
        val t4 = tile(R.drawable.ic_p_palette, "Cor", colorsOpen) {
            colorsOpen = !colorsOpen; refreshPanelInPlace()
        }
        val t5 = tile(R.drawable.ic_p_gamepad, "Launcher", false) {
            startActivity(Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        }
        val t6 = tile(R.drawable.ic_p_power, "Desligar", false) { stopSelf() }

        for (rowTiles in listOf(listOf(t1, t2, t3), listOf(t4, t5, t6))) {
            val row = LinearLayout(this)
            row.orientation = LinearLayout.HORIZONTAL
            for ((i, t) in rowTiles.withIndex()) {
                row.addView(t, LinearLayout.LayoutParams(0, dp(70), 1f).apply {
                    if (i > 0) leftMargin = dp(8)
                })
            }
            grid.addView(row, LinearLayout.LayoutParams(-1, -2).apply {
                if (grid.childCount > 0) topMargin = dp(8)
            })
        }
        return grid
    }

    private fun tile(iconRes: Int, text: String, active: Boolean, onClick: () -> Unit): LinearLayout {
        val v = LinearLayout(this)
        v.orientation = LinearLayout.VERTICAL
        v.gravity = Gravity.CENTER
        v.setPadding(dp(4), dp(6), dp(4), dp(6))
        v.background = CutDrawable(
            if (active) alpha(accent, 90) else 0x55223253,
            if (active) alpha(accent, 40) else 0x55101A30,
            if (active) accent else 0x44FFFFFF,
            accent, dpf(10f), dpf(1.1f), CutDrawable.BR
        )
        v.addView(icon(iconRes, 27, if (active) Color.WHITE else accent))
        val l = label(text, 10.5f, if (active) Color.WHITE else 0xFFD3DCEE.toInt(), true)
        l.maxLines = 1
        v.addView(l, LinearLayout.LayoutParams(-2, -2).apply { topMargin = dp(5) })
        pressable(v, onClick)
        return v
    }

    private fun buildColorCard(): View {
        val card = LinearLayout(this)
        card.orientation = LinearLayout.VERTICAL
        card.setPadding(dp(10), dp(8), dp(10), dp(8))
        card.background = CutDrawable(
            0x66141F38, 0x66090F1E, alpha(accent, 120), accent, dpf(12f), dpf(1.1f), CutDrawable.BR
        )

        val head = LinearLayout(this)
        head.orientation = LinearLayout.HORIZONTAL
        head.gravity = Gravity.CENTER_VERTICAL
        val title = label("COR DO PAINEL", 10f, 0xFF9AA8C2.toInt(), true)
        title.letterSpacing = 0.12f
        head.addView(title, LinearLayout.LayoutParams(0, -2, 1f))

        val side = LinearLayout(this)
        side.orientation = LinearLayout.HORIZONTAL
        side.gravity = Gravity.CENTER_VERTICAL
        side.setPadding(dp(9), dp(5), dp(9), dp(5))
        side.background = CutDrawable(0x33FFFFFF, 0x11FFFFFF, 0x44FFFFFF, accent, dpf(6f), dpf(1f), CutDrawable.BR)
        side.addView(icon(R.drawable.ic_p_swap, 15, accent))
        val st = label(if (right) "Lado: direita" else "Lado: esquerda", 10.5f, Color.WHITE, true)
        st.setPadding(dp(5), 0, 0, 0)
        side.addView(st)
        pressable(side) {
            right = !right
            AccentStore.writeRight(this, right)
            // fecha e reabre do outro lado
            removePanelNow()
            rebuildHandle()
            handleView?.visibility = View.GONE
            openPanel()
        }
        head.addView(side)
        card.addView(head)

        val sw = LinearLayout(this)
        sw.orientation = LinearLayout.HORIZONTAL
        sw.gravity = Gravity.CENTER_VERTICAL
        for (c in AccentStore.presets) {
            val sel = c == accent
            val dot = View(this)
            dot.background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(c)
                if (sel) setStroke(dp(2), Color.WHITE) else setStroke(dp(1), 0x44FFFFFF)
            }
            pressable(dot) { if (c != accent) setAccent(c) }
            sw.addView(dot, LinearLayout.LayoutParams(0, dp(if (sel) 26 else 22), 1f).apply {
                marginEnd = dp(4); marginStart = dp(4)
            })
        }
        card.addView(sw, LinearLayout.LayoutParams(-1, dp(30)).apply { topMargin = dp(8) })

        val hue = HueBar(this, accent) { picked -> handler.post { setAccent(picked) } }
        card.addView(hue, LinearLayout.LayoutParams(-1, dp(30)).apply { topMargin = dp(2) })
        return card
    }

    // ---------------------------------------------------------------- ações

    private fun cleanMemory() {
        val am = getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val before = MemoryInfoCompat.avail(am)
        Thread {
            Perf.boost(this, gamePkg ?: "")
            handler.postDelayed({
                val freed = ((MemoryInfoCompat.avail(am) - before) / 1_000_000L).coerceAtLeast(0)
                Toast.makeText(this, "Memória limpa: +$freed MB livres", Toast.LENGTH_SHORT).show()
                update()
            }, 700)
        }.start()
    }

    private fun toggleDnd() {
        if (!Dnd.hasAccess(this)) {
            Toast.makeText(this, "Permita o acesso a Não perturbar nas configurações do Android", Toast.LENGTH_LONG).show()
            return
        }
        val on = getSharedPreferences("launcher", Context.MODE_PRIVATE).getInt("dnd_prev", -1) != -1
        if (on) Dnd.restore(this) else Dnd.enable(this)
        refreshPanelInPlace()
    }

    // ---------------------------------------------------------------- dados ao vivo

    private fun update() {
        val p = panel ?: return
        if (p.parent == null) return
        val dm = getSystemService(Context.DISPLAY_SERVICE) as DisplayManager
        val hz = dm.getDisplay(Display.DEFAULT_DISPLAY)?.refreshRate

        val am = getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val mi = ActivityManager.MemoryInfo()
        am.getMemoryInfo(mi)
        val ramFrac = if (mi.totalMem > 0) (mi.totalMem - mi.availMem).toFloat() / mi.totalMem else 0f

        val b = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val level = b?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
        val scale = b?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100
        val pct = if (level >= 0 && scale > 0) level * 100 / scale else -1
        val batTemp = (b?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) ?: 0) / 10.0
        val st = b?.getIntExtra(BatteryManager.EXTRA_STATUS, -1) ?: -1
        val charging = st == BatteryManager.BATTERY_STATUS_CHARGING || st == BatteryManager.BATTERY_STATUS_FULL

        val raw = cpuTempPath?.let { readLong(it) }
        val cpuT = raw?.let { if (it > 1000) it / 1000.0 else it.toDouble() }?.takeIf { it in 1.0..120.0 }

        val cpu = cpuInfo()
        usingCpu = cpu != null
        val sample = cpu?.ratio ?: ramFrac
        history.add(sample)
        while (history.size > GraphView.MAX) history.removeAt(0)

        graph?.setData(history)
        graphTitle?.text = if (usingCpu) "CARGA DA CPU" else "USO DE RAM"
        hzBig?.text = bigText(if (hz != null) "${Math.round(hz)}" else "--", "Hz")
        if (cpu != null) {
            cpuBig?.text = bigText("${(cpu.ratio * 100).toInt()}", "%")
            cpuLabel?.text = "CPU · ${"%.1f".format(cpu.maxMhz / 1000.0)} GHz"
        } else {
            cpuBig?.text = bigText("${(ramFrac * 100).toInt()}", "%")
            cpuLabel?.text = "RAM"
        }
        tempText?.text = if (cpuT != null) "${"%.0f".format(cpuT)}° / ${"%.0f".format(batTemp)}°" else "${"%.0f".format(batTemp)}°"
        ramText?.text = "${(ramFrac * 100).toInt()}%"
        batText?.text = (if (charging) "⚡" else "") + (if (pct >= 0) "$pct%" else "--")

        val secs = (SystemClock.elapsedRealtime() - sessionStart) / 1000
        timerText?.text = "%02d:%02d".format(secs / 60, secs % 60)
    }

    private class CpuInfo(val ratio: Float, val maxMhz: Long)

    private fun cpuInfo(): CpuInfo? {
        val n = Runtime.getRuntime().availableProcessors()
        var maxCur = 0L
        var ratioSum = 0.0
        var count = 0
        for (i in 0 until n) {
            val base = "/sys/devices/system/cpu/cpu$i/cpufreq/"
            val cur = readLong(base + "scaling_cur_freq") ?: continue
            val max = readLong(base + "cpuinfo_max_freq") ?: continue
            if (max <= 0) continue
            if (cur > maxCur) maxCur = cur
            ratioSum += cur.toDouble() / max
            count++
        }
        if (count == 0) return null
        return CpuInfo((ratioSum / count).toFloat().coerceIn(0f, 1f), maxCur / 1000)
    }

    private fun readLong(path: String): Long? =
        runCatching { File(path).readText().trim().toLongOrNull() }.getOrNull()

    private fun findCpuTempPath(): String? {
        val zones = File("/sys/class/thermal").listFiles()
            ?.filter { it.name.startsWith("thermal_zone") } ?: return null
        for (key in listOf("cpu", "soc", "tsens")) {
            for (z in zones) {
                val type = runCatching { File(z, "type").readText().trim().lowercase() }.getOrNull() ?: continue
                val tempPath = File(z, "temp").path
                if (type.contains(key) && readLong(tempPath) != null) return tempPath
            }
        }
        return null
    }

    private object MemoryInfoCompat {
        fun avail(am: ActivityManager): Long {
            val mi = ActivityManager.MemoryInfo()
            am.getMemoryInfo(mi)
            return mi.availMem
        }
    }

    companion object {
        private const val CHANNEL = "overlay"
        const val EXTRA_GAME = "game"
    }
}
