package com.thblue.gamelauncher

import android.app.ActivityManager
import android.provider.Settings
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ServiceInfo
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Rect
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.hardware.display.DisplayManager
import android.media.AudioManager
import android.os.HandlerThread
import android.view.KeyEvent
import android.os.BatteryManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.SystemClock
import android.text.SpannableStringBuilder
import android.text.Spanned
import android.text.style.RelativeSizeSpan
import android.util.TypedValue
import android.view.Display
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.view.animation.OvershootInterpolator
import android.view.animation.PathInterpolator
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import java.io.File

/**
 * Painel de jogo: uma aba fica na borda da tela; puxe (ou toque) para o painel deslizar.
 * Mostra gráfico ao vivo, Hz, CPU, temperatura, RAM, bateria, atalhos e a cor do painel.
 */
class OverlayService : Service() {
    private lateinit var wm: WindowManager
    private val handler = Handler(Looper.getMainLooper())
    private val density get() = resources.displayMetrics.density

    private var handleView: HandleView? = null
    private var panel: SwipeCloseLayout? = null
    private var closing = false
    private enum class Tab { MAIN, FILES, VISUAL }
    private var tab = Tab.MAIN

    private var accent = AccentStore.DEFAULT
    private var right = false
    private var gamePkg: String? = null
    private var sessionStart = SystemClock.elapsedRealtime()
    private val history = ArrayList<Float>()
    private var usingCpu = true
    private val cpuTempPath: String? by lazy { findCpuTempPath() }

    // Referências para atualizar a cada segundo.
    private var graph: GraphView? = null
    private var graphTitle: TextView? = null
    private var hzBig: TextView? = null
    private var cpuBig: TextView? = null
    private var cpuLabel: TextView? = null
    private var tempText: TextView? = null
    private var ramText: TextView? = null
    private var batText: TextView? = null
    private var timerText: TextView? = null
    private var panelBgPath: String? = null
    private var panelBgBmp: android.graphics.Bitmap? = null
    private var musicBtn: ImageView? = null
    private var musicSub: TextView? = null
    private var musicPlaying = false
    private val audioManager by lazy { getSystemService(Context.AUDIO_SERVICE) as AudioManager }
    private var playbackCb: AudioManager.AudioPlaybackCallback? = null
    private val bgThread = HandlerThread("panel-sampler").also { it.start() }
    private val bg = Handler(bgThread.looper)
    private val staggerViews = ArrayList<View>()
    private var cpuMax: LongArray? = null

    private val tick = object : Runnable {
        override fun run() {
            val smp = runCatching { sample() }.getOrNull()
            if (smp != null) handler.post { render(smp) }
            bg.postDelayed(this, 1000)
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startAsForeground()
        intent?.getStringExtra(EXTRA_GAME)?.let { gamePkg = it }
        if (handleView == null) {
            wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
            accent = AccentStore.read(this)
            right = AccentStore.readRight(this)
            sessionStart = SystemClock.elapsedRealtime()
            showHandle()
        }
        return START_NOT_STICKY
    }

    override fun onConfigurationChanged(newConfig: android.content.res.Configuration) {
        super.onConfigurationChanged(newConfig)
        if (panel != null && !closing) handler.post { refreshPanelInPlace() }
        // girou a tela: recoloca a aba na mesma posição proporcional
        handleView?.let { h ->
            handler.post {
                val lp = h.layoutParams as? WindowManager.LayoutParams ?: return@post
                lp.y = handleYPx()
                runCatching { wm.updateViewLayout(h, lp) }
            }
        }
    }

    override fun onDestroy() {
        unwatchMusic()
        thumbExec.shutdownNow()
        handler.removeCallbacksAndMessages(null)
        bg.removeCallbacksAndMessages(null)
        bgThread.quitSafely()
        panel?.let { runCatching { wm.removeView(it) } }
        handleView?.let { runCatching { wm.removeView(it) } }
        panel = null
        handleView = null
        super.onDestroy()
    }

    private fun startAsForeground() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL, "Painel de desempenho", NotificationManager.IMPORTANCE_MIN)
        )
        val n = Notification.Builder(this, CHANNEL)
            .setContentTitle("Painel de desempenho ativo")
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setOngoing(true)
            .build()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(1, n)
        }
    }

    // ---------------------------------------------------------------- helpers

    private fun dp(v: Int) = (v * density).toInt()
    private fun dpf(v: Float) = v * density

    private fun screenSize(): Pair<Int, Int> {
        val m = android.util.DisplayMetrics()
        val dm = getSystemService(Context.DISPLAY_SERVICE) as DisplayManager
        val d = dm.getDisplay(Display.DEFAULT_DISPLAY)
        @Suppress("DEPRECATION")
        d.getRealMetrics(m)
        return m.widthPixels to m.heightPixels
    }

    private fun panelWidth(sw: Int, sh: Int): Int =
        if (sw > sh) minOf((sw * 0.55f).toInt(), dp(520)) else minOf(sw - dp(12), dp(360))

    private fun alpha(color: Int, a: Int) = Color.argb(a, Color.red(color), Color.green(color), Color.blue(color))

    private fun icon(res: Int, sizeDp: Int, tint: Int): ImageView {
        val v = ImageView(this)
        v.setImageResource(res)
        v.setColorFilter(tint)
        v.layoutParams = LinearLayout.LayoutParams(dp(sizeDp), dp(sizeDp))
        return v
    }

    private fun label(text: String, sp: Float, color: Int, bold: Boolean = false): TextView {
        val t = TextView(this)
        t.text = text
        t.setTextSize(TypedValue.COMPLEX_UNIT_DIP, sp)
        t.setTextColor(color)
        t.includeFontPadding = false
        t.typeface = Typeface.create("sans-serif-condensed", if (bold) Typeface.BOLD else Typeface.NORMAL)
        return t
    }

    private fun bigText(value: String, unit: String): CharSequence {
        val sb = SpannableStringBuilder(value)
        if (unit.isNotEmpty()) {
            sb.append(" ").append(unit)
            sb.setSpan(RelativeSizeSpan(0.5f), value.length, sb.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        }
        return sb
    }

    /** Efeito de toque: encolhe um pouco enquanto pressionado. */
    private fun pressable(v: View, onClick: () -> Unit) {
        v.setOnTouchListener { view, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> view.animate().scaleX(0.94f).scaleY(0.94f).alpha(0.85f).setDuration(80).start()
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    view.animate().scaleX(1f).scaleY(1f).alpha(1f).setDuration(280)
                        .setInterpolator(OvershootInterpolator(2.4f)).start()
                    if (e.actionMasked == MotionEvent.ACTION_UP &&
                        e.x in 0f..view.width.toFloat() && e.y in 0f..view.height.toFloat()
                    ) {
                        view.performHapticFeedback(android.view.HapticFeedbackConstants.VIRTUAL_KEY)
                        handler.post { onClick() }
                    }
                }
            }
            true
        }
    }

    // ---------------------------------------------------------------- aba na borda

    private val handleH get() = dp(88)

    /** Converte a fração salva (0..1) na posição Y em pixels, sempre dentro da tela. */
    private fun handleYPx(): Int {
        val (_, sh) = screenSize()
        val maxY = (sh - handleH).coerceAtLeast(0)
        return (AccentStore.readHandleY(this) * maxY).toInt().coerceIn(0, maxY)
    }

    private fun showHandle() {
        val h = HandleView(this, accent, right)
        h.onOpen = { openPanel() }
        var startY = 0
        h.onDragStart = { startY = (h.layoutParams as WindowManager.LayoutParams).y }
        h.onDrag = { dy ->
            val lp = h.layoutParams as WindowManager.LayoutParams
            val maxY = (screenSize().second - handleH).coerceAtLeast(0)
            lp.y = (startY + dy.toInt()).coerceIn(0, maxY)
            runCatching { wm.updateViewLayout(h, lp) }
        }
        h.onDragEnd = {
            val lp = h.layoutParams as WindowManager.LayoutParams
            val maxY = (screenSize().second - handleH).coerceAtLeast(1)
            AccentStore.writeHandleY(this, lp.y.toFloat() / maxY)
        }
        val lp = WindowManager.LayoutParams(
            dp(24), handleH,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = (if (right) Gravity.END else Gravity.START) or Gravity.TOP
        lp.y = handleYPx()
        runCatching { wm.addView(h, lp) }.onSuccess {
            handleView = h
            h.translationX = if (right) dpf(24f) else -dpf(24f)
            h.animate().translationX(0f).setDuration(450).setStartDelay(150).setInterpolator(IOS).start()
            if (Build.VERSION.SDK_INT >= 29) {
                h.post { h.systemGestureExclusionRects = listOf(Rect(0, 0, h.width, h.height)) }
            }
        }
    }

    private fun rebuildHandle() {
        handleView?.let { runCatching { wm.removeView(it) } }
        handleView = null
        showHandle()
    }

    // ---------------------------------------------------------------- abrir / fechar

    private fun openPanel() {
        if (panel != null || closing) return
        val (sw, sh) = screenSize()
        val p = runCatching { buildPanel(sw, sh) }.getOrNull() ?: return
        val lp = WindowManager.LayoutParams(
            panelWidth(sw, sh), WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = (if (right) Gravity.END else Gravity.START) or Gravity.CENTER_VERTICAL
        lp.x = dp(6)
        p.alpha = 0f
        val items = ArrayList(staggerViews)
        for (v in items) { v.alpha = 0f; v.translationY = dpf(14f) }
        if (runCatching { wm.addView(p, lp) }.isFailure) return
        panel = p
        handleView?.visibility = View.GONE
        p.post {
            val w = p.width.toFloat()
            p.translationX = if (right) w else -w
            p.alpha = 1f
            p.setLayerType(View.LAYER_TYPE_HARDWARE, null)
            p.animate().translationX(0f).setDuration(430).setInterpolator(IOS)
                .withEndAction { p.setLayerType(View.LAYER_TYPE_NONE, null) }.start()
            for ((i, v) in items.withIndex()) {
                v.animate().alpha(1f).translationY(0f).setStartDelay(90L + i * 40L)
                    .setDuration(380).setInterpolator(IOS).start()
            }
        }
        history.clear()
        bg.removeCallbacks(tick)
        bg.post(tick)
        watchMusic()
    }

    private fun closePanel() {
        val p = panel ?: return
        if (closing) return
        closing = true
        unwatchMusic()
        bg.removeCallbacks(tick)
        val w = p.width.toFloat()
        p.setLayerType(View.LAYER_TYPE_HARDWARE, null)
        p.animate().translationX(if (right) w else -w).setDuration(280)
            .setInterpolator(IOS_OUT)
            .withEndAction {
                removePanelNow()
                tab = Tab.MAIN
                handleView?.let { it.visibility = View.VISIBLE; it.wake() }
                closing = false
            }.start()
    }

    private fun removePanelNow() {
        unwatchMusic()
        panel?.let { runCatching { wm.removeView(it) } }
        panel = null
        removeRefs()
    }

    /** Refaz o painel na hora (sem animação), por exemplo depois de trocar a cor. */
    private fun refreshPanelInPlace() {
        val old = panel ?: return
        val lp = old.layoutParams as WindowManager.LayoutParams
        val (sw, sh) = screenSize()
        lp.width = panelWidth(sw, sh)
        runCatching { wm.removeView(old) }
        removeRefs()
        val fresh = buildPanel(sw, sh)
        panel = if (runCatching { wm.addView(fresh, lp) }.isSuccess) fresh else null
        update()
    }

    private fun removeRefs() {
        graph = null; graphTitle = null; hzBig = null; cpuBig = null; cpuLabel = null
        tempText = null; ramText = null; batText = null; timerText = null
        musicBtn = null; musicSub = null
    }

    private fun setAccent(c: Int) {
        accent = c
        AccentStore.write(this, c)
        rebuildHandle()
        handleView?.visibility = View.GONE
        refreshPanelInPlace()
    }

    // ---------------------------------------------------------------- construção do painel

    private fun buildPanel(sw: Int, sh: Int): SwipeCloseLayout {
        val landscape = sw > sh
        val root = SwipeCloseLayout(this, if (right) 1 else -1) { closePanel() }
        val photo = panelPhoto()
        root.background = CutDrawable(
            if (photo != null) 0xB00A1222.toInt() else 0xF40A1222.toInt(),
            if (photo != null) 0xD0060B16.toInt() else 0xF4060B16.toInt(),
            alpha(accent, 200), accent, dpf(18f), dpf(1.4f),
            CutDrawable.TR or CutDrawable.BL,
            photo
        )
        root.setPadding(dp(4), dp(4), dp(4), dp(4))

        val column = LinearLayout(this)
        column.orientation = LinearLayout.VERTICAL
        column.setPadding(dp(12), dp(8), dp(12), dp(12))

        column.addView(buildHeader())
        column.addView(buildTabs(), LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(6) })
        staggerViews.clear()

        when (tab) {
            Tab.FILES -> column.addView(buildFilesView(), LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(10) })
            Tab.VISUAL -> {
                column.addView(buildPhotoCard(), LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(10) })
                column.addView(buildColorCard(), LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(10) })
            }
            Tab.MAIN -> addMainTab(column, landscape)
        }

        val scroll = MaxHeightScroll(this, sh - dp(40))
        scroll.isVerticalScrollBarEnabled = false
        scroll.overScrollMode = View.OVER_SCROLL_NEVER
        scroll.addView(column)
        root.addView(scroll, android.widget.FrameLayout.LayoutParams(-1, -2))
        return root
    }

    private fun addMainTab(column: LinearLayout, landscape: Boolean) {
        val body = LinearLayout(this)
        body.orientation = if (landscape) LinearLayout.HORIZONTAL else LinearLayout.VERTICAL
        val graphCard = buildGraphCard(landscape)
        staggerViews.add(graphCard)
        val tiles = buildTiles()
        if (landscape) {
            body.addView(graphCard, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1.05f))
            body.addView(tiles, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f).apply {
                leftMargin = dp(10)
            })
        } else {
            body.addView(graphCard, LinearLayout.LayoutParams(-1, -2))
            body.addView(tiles, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(10) })
        }
        column.addView(body, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(6) })

        val music = buildMusicCard()
        staggerViews.add(music)
        column.addView(music, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(10) })
    }

    // ---------------------------------------------------------------- abas

    private fun buildTabs(): View {
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        fun tabBtn(t: Tab, res: Int, name: String): View {
            val sel = tab == t
            val c = LinearLayout(this)
            c.orientation = LinearLayout.HORIZONTAL
            c.gravity = Gravity.CENTER
            c.setPadding(dp(6), dp(8), dp(6), dp(8))
            c.background = if (sel) CutDrawable(
                alpha(accent, 110), alpha(accent, 45), accent, accent, dpf(8f), dpf(1.1f), CutDrawable.BR
            ) else CutDrawable(0x33223253, 0x33101A30, 0x33FFFFFF, accent, dpf(8f), dpf(1f), CutDrawable.BR)
            c.addView(icon(res, 16, if (sel) Color.WHITE else 0xFF9AA8C2.toInt()))
            val l = label(name, 12f, if (sel) Color.WHITE else 0xFF9AA8C2.toInt(), true)
            l.setPadding(dp(5), 0, 0, 0)
            l.maxLines = 1
            c.addView(l)
            pressable(c) { if (tab != t) { tab = t; refreshPanelInPlace() } }
            return c
        }
        val items = listOf(
            tabBtn(Tab.MAIN, R.drawable.ic_p_gamepad, "Desempenho"),
            tabBtn(Tab.FILES, R.drawable.ic_p_chip, "Arquivos"),
            tabBtn(Tab.VISUAL, R.drawable.ic_p_palette, "Visual")
        )
        for ((i, v) in items.withIndex()) {
            row.addView(v, LinearLayout.LayoutParams(0, -2, 1f).apply { if (i > 0) leftMargin = dp(6) })
        }
        return row
    }

    private fun smallBtn(text: String, danger: Boolean = false, onClick: () -> Unit): TextView {
        val b = label(text, 12f, if (danger) 0xFFF87171.toInt() else Color.WHITE, true)
        b.gravity = Gravity.CENTER
        b.setPadding(dp(10), dp(9), dp(10), dp(9))
        b.background = CutDrawable(0x55223253, 0x55101A30, 0x44FFFFFF, accent, dpf(8f), dpf(1f), CutDrawable.BR)
        pressable(b, onClick)
        return b
    }

    private fun cardBox(): LinearLayout {
        val card = LinearLayout(this)
        card.orientation = LinearLayout.VERTICAL
        card.setPadding(dp(10), dp(8), dp(10), dp(10))
        card.background = CutDrawable(
            0x66141F38, 0x66090F1E, alpha(accent, 120), accent, dpf(12f), dpf(1.1f), CutDrawable.BR
        )
        return card
    }

    // ---------------------------------------------------------------- aba Arquivos (mini gerenciador de arquivos)

    private val thumbExec = java.util.concurrent.Executors.newSingleThreadExecutor()
    private var fmDir: File? = null
    private var fmLimit = 30

    private fun fsRoot(): File = android.os.Environment.getExternalStorageDirectory()

    private fun hasFileAccess(): Boolean =
        if (Build.VERSION.SDK_INT >= 30) android.os.Environment.isExternalStorageManager()
        else checkSelfPermission(android.Manifest.permission.READ_EXTERNAL_STORAGE) ==
            android.content.pm.PackageManager.PERMISSION_GRANTED

    private fun askFileAccess() {
        val i = if (Build.VERSION.SDK_INT >= 30) {
            Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION, android.net.Uri.parse("package:$packageName"))
        } else {
            Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, android.net.Uri.parse("package:$packageName"))
        }
        runCatching { startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
    }

    private fun isImage(f: File): Boolean =
        f.extension.lowercase() in setOf("jpg", "jpeg", "png", "webp", "bmp")

    private fun thumb(iv: ImageView, f: File) {
        iv.tag = f.path
        thumbExec.execute {
            val bmp = runCatching {
                val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                BitmapFactory.decodeFile(f.path, o)
                var sample = 1
                while (maxOf(o.outWidth, o.outHeight) / (sample * 2) >= 120) sample *= 2
                BitmapFactory.decodeFile(f.path, BitmapFactory.Options().apply { inSampleSize = sample })
            }.getOrNull()
            if (bmp != null) handler.post { if (iv.tag == f.path) iv.setImageBitmap(bmp) }
        }
    }

    private fun applyPhoto(f: File) {
        val profile = currentProfile() ?: return
        Toast.makeText(this, "Aplicando foto…", Toast.LENGTH_SHORT).show()
        Thread {
            val ok = BgStore.save(this, profile, BgStore.PANEL, android.net.Uri.fromFile(f)) != null
            handler.post {
                Toast.makeText(this, if (ok) "Foto aplicada" else "Não consegui abrir essa foto", Toast.LENGTH_SHORT).show()
                if (panel != null && !closing) { if (ok) tab = Tab.VISUAL; refreshPanelInPlace() }
            }
        }.start()
    }

    private fun buildFilesView(): View {
        val card = cardBox()
        val t = label("ESCOLHER FOTO DO PAINEL", 10f, 0xFF9AA8C2.toInt(), true)
        t.letterSpacing = 0.12f
        card.addView(t)

        if (!hasFileAccess()) {
            card.addView(
                label("Para navegar pelas suas pastas e escolher uma foto, permita o acesso aos arquivos.", 11.5f, 0xFFC9D4E8.toInt()),
                LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(8) }
            )
            card.addView(smallBtn("Permitir acesso aos arquivos") { askFileAccess() },
                LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(8) })
            return card
        }

        val root = fsRoot()
        val dir = (fmDir?.takeIf { it.exists() && it.canonicalPath.startsWith(root.canonicalPath) }) ?: root
        fmDir = dir

        // atalhos
        val shortcuts = LinearLayout(this)
        shortcuts.orientation = LinearLayout.HORIZONTAL
        for ((i, pair) in listOf("Fotos" to "DCIM", "Imagens" to "Pictures", "Downloads" to "Download").withIndex()) {
            shortcuts.addView(smallBtn(pair.first) {
                fmDir = File(root, pair.second); fmLimit = 30; refreshPanelInPlace()
            }, LinearLayout.LayoutParams(0, -2, 1f).apply { if (i > 0) leftMargin = dp(6) })
        }
        card.addView(shortcuts, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(8) })

        // caminho atual + subir
        val rel = runCatching { dir.relativeTo(root).path }.getOrDefault("")
        val bar = LinearLayout(this)
        bar.orientation = LinearLayout.HORIZONTAL
        bar.gravity = Gravity.CENTER_VERTICAL
        val path = label(if (rel.isEmpty()) "Armazenamento interno" else rel.replace("/", " › "), 11.5f, Color.WHITE, true)
        path.maxLines = 1
        path.ellipsize = android.text.TextUtils.TruncateAt.START
        bar.addView(path, LinearLayout.LayoutParams(0, -2, 1f))
        if (dir.canonicalPath != root.canonicalPath) {
            bar.addView(smallBtn("↑ Subir") {
                fmDir = dir.parentFile; fmLimit = 30; refreshPanelInPlace()
            })
        }
        card.addView(bar, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(10) })

        val all = dir.listFiles().orEmpty()
        val folders = all.filter { it.isDirectory && !it.name.startsWith(".") }.sortedBy { it.name.lowercase() }
        val images = all.filter { it.isFile && isImage(it) }.sortedByDescending { it.lastModified() }
        val entries = folders + images

        if (entries.isEmpty()) {
            card.addView(
                label("Nenhuma pasta ou foto aqui.", 11.5f, 0xFFAFBBD2.toInt()),
                LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(10) }
            )
        }

        for (f in entries.take(fmLimit)) {
            val row = LinearLayout(this)
            row.orientation = LinearLayout.HORIZONTAL
            row.gravity = Gravity.CENTER_VERTICAL
            row.setPadding(dp(6), dp(6), dp(6), dp(6))
            row.background = CutDrawable(0x33223253, 0x33101A30, 0x22FFFFFF, accent, dpf(8f), dpf(1f), CutDrawable.BR)
            if (f.isDirectory) {
                val ic = label("📁", 20f, Color.WHITE)
                ic.gravity = Gravity.CENTER
                row.addView(ic, LinearLayout.LayoutParams(dp(40), dp(40)))
            } else {
                val iv = ImageView(this)
                iv.scaleType = ImageView.ScaleType.CENTER_CROP
                iv.background = GradientDrawable().apply { cornerRadius = dpf(6f); setColor(0x33FFFFFF) }
                iv.clipToOutline = true
                iv.outlineProvider = object : android.view.ViewOutlineProvider() {
                    override fun getOutline(v: View, o: android.graphics.Outline) {
                        o.setRoundRect(0, 0, v.width, v.height, dpf(6f))
                    }
                }
                row.addView(iv, LinearLayout.LayoutParams(dp(40), dp(40)))
                thumb(iv, f)
            }
            val col = LinearLayout(this)
            col.orientation = LinearLayout.VERTICAL
            col.addView(label(f.name, 12.5f, Color.WHITE, true).apply {
                maxLines = 1; ellipsize = android.text.TextUtils.TruncateAt.MIDDLE
            })
            if (f.isFile) col.addView(label("${f.length() / 1024} KB · toque para usar", 10f, 0xFFAFBBD2.toInt()))
            row.addView(col, LinearLayout.LayoutParams(0, -2, 1f).apply { leftMargin = dp(10) })
            pressable(row) {
                if (f.isDirectory) { fmDir = f; fmLimit = 30; refreshPanelInPlace() } else applyPhoto(f)
            }
            card.addView(row, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(6) })
        }

        if (entries.size > fmLimit) {
            card.addView(smallBtn("Mostrar mais (${entries.size - fmLimit})") {
                fmLimit += 30; refreshPanelInPlace()
            }, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(8) })
        }
        return card
    }

    // ---------------------------------------------------------------- aba Visual (foto do painel)

    private fun currentProfile(): String? =
        getSharedPreferences("launcher", Context.MODE_PRIVATE).getString("current", null)

    private fun buildPhotoCard(): View {
        val card = cardBox()
        val t = label("FOTO DO PAINEL", 10f, 0xFF9AA8C2.toInt(), true)
        t.letterSpacing = 0.12f
        card.addView(t)

        val photo = panelPhoto()
        if (photo != null) {
            val iv = ImageView(this)
            iv.scaleType = ImageView.ScaleType.CENTER_CROP
            iv.setImageBitmap(photo)
            iv.background = GradientDrawable().apply { cornerRadius = dpf(8f); setColor(0x33FFFFFF) }
            iv.clipToOutline = true
            iv.outlineProvider = object : android.view.ViewOutlineProvider() {
                override fun getOutline(v: View, o: android.graphics.Outline) {
                    o.setRoundRect(0, 0, v.width, v.height, dpf(8f))
                }
            }
            card.addView(iv, LinearLayout.LayoutParams(-1, dp(76)).apply { topMargin = dp(8) })
        } else {
            card.addView(
                label("Sem foto. O painel usa o fundo padrão.", 11.5f, 0xFFC9D4E8.toInt()),
                LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(8) }
            )
        }

        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.addView(smallBtn("Escolher foto") { tab = Tab.FILES; refreshPanelInPlace() }, LinearLayout.LayoutParams(0, -2, 1f))
        if (photo != null) {
            row.addView(smallBtn("Remover", danger = true) {
                currentProfile()?.let { BgStore.clear(this, it, BgStore.PANEL) }
                refreshPanelInPlace()
            }, LinearLayout.LayoutParams(0, -2, 1f).apply { leftMargin = dp(8) })
        }
        card.addView(row, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(10) })

        val profile = currentProfile()
        val launcherPhoto = BgStore.pathFor(this, profile, BgStore.LAUNCHER)
        if (profile != null && launcherPhoto != null) {
            card.addView(smallBtn("Usar a foto do launcher") {
                BgStore.copy(this, profile, BgStore.LAUNCHER, BgStore.PANEL)
                refreshPanelInPlace()
            }, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(8) })
        }
        return card
    }


    /** Foto personalizada do painel (escolhida no launcher), com cache para não reler a cada refresh. */
    private fun panelPhoto(): android.graphics.Bitmap? {
        val path = BgStore.current(this, BgStore.PANEL)
        if (path == null) { panelBgPath = null; panelBgBmp = null; return null }
        if (path != panelBgPath) {
            panelBgBmp = BgStore.load(path)
            panelBgPath = path
        }
        return panelBgBmp
    }

    private fun buildHeader(): View {
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL

        val title = label("GAME PANEL", 21f, accent, true)
        title.typeface = Typeface.create("sans-serif-condensed", Typeface.BOLD_ITALIC)
        title.letterSpacing = 0.08f
        title.setShadowLayer(dpf(9f), 0f, 0f, alpha(accent, 220))
        row.addView(title)

        val s = getSharedPreferences("launcher", Context.MODE_PRIVATE)
        val cur = s.getString("current", null)
        val mode = runCatching {
            PerfMode.valueOf(s.getString("p.$cur.mode", null) ?: "PERFORMANCE").label
        }.getOrDefault("Desempenho")
        val chip = label("${cur ?: "Jogador"} · $mode", 12f, 0xFFC9D4E8.toInt(), true)
        chip.gravity = Gravity.END
        chip.maxLines = 1
        chip.ellipsize = android.text.TextUtils.TruncateAt.END
        chip.setPadding(dp(8), 0, dp(8), 0)
        row.addView(chip, LinearLayout.LayoutParams(0, -2, 1f))

        val close = icon(R.drawable.ic_p_close, 18, 0xFFC9D4E8.toInt())
        close.setPadding(dp(7), dp(7), dp(7), dp(7))
        close.layoutParams = LinearLayout.LayoutParams(dp(34), dp(34))
        close.background = CutDrawable(0x22FFFFFF, 0x11FFFFFF, 0x33FFFFFF, accent, dpf(7f), dpf(1f), CutDrawable.BR)
        pressable(close) { closePanel() }
        row.addView(close)
        return row
    }

    private fun buildGraphCard(landscape: Boolean): View {
        val card = LinearLayout(this)
        card.orientation = LinearLayout.VERTICAL
        card.setPadding(dp(10), dp(8), dp(10), dp(10))
        card.background = CutDrawable(
            0x66141F38, 0x66090F1E, alpha(accent, 120), accent, dpf(14f), dpf(1.2f), CutDrawable.TR
        )

        val top = LinearLayout(this)
        top.orientation = LinearLayout.HORIZONTAL
        top.gravity = Gravity.CENTER_VERTICAL
        val title = label(if (usingCpu) "CARGA DA CPU" else "USO DE RAM", 10f, 0xFF9AA8C2.toInt(), true)
        title.letterSpacing = 0.12f
        graphTitle = title
        top.addView(title, LinearLayout.LayoutParams(0, -2, 1f))
        card.addView(top)

        val g = GraphView(this, accent)
        graph = g
        card.addView(g, LinearLayout.LayoutParams(-1, dp(if (landscape) 78 else 92)).apply { topMargin = dp(4) })
        g.setData(history)

        // números grandes: Tela (Hz) e CPU
        val big = LinearLayout(this)
        big.orientation = LinearLayout.HORIZONTAL
        big.addView(bigStat("Tela", true), LinearLayout.LayoutParams(0, -2, 1f))
        big.addView(bigStat("CPU", false), LinearLayout.LayoutParams(0, -2, 1f))
        card.addView(big, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(8) })

        // mini estatísticas
        val mini = LinearLayout(this)
        mini.orientation = LinearLayout.HORIZONTAL
        mini.setPadding(0, dp(8), 0, 0)
        val (m1, t1) = miniStat(R.drawable.ic_p_thermo); tempText = t1
        val (m2, t2) = miniStat(R.drawable.ic_p_ram); ramText = t2
        val (m3, t3) = miniStat(R.drawable.ic_p_battery); batText = t3
        mini.addView(m1, LinearLayout.LayoutParams(0, -2, 1f))
        mini.addView(m2, LinearLayout.LayoutParams(0, -2, 1f))
        mini.addView(m3, LinearLayout.LayoutParams(0, -2, 1f))
        card.addView(mini, LinearLayout.LayoutParams(-1, -2))
        return card
    }

    private fun bigStat(name: String, isHz: Boolean): View {
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        val value = label("--", 26f, Color.WHITE, true)
        value.typeface = Typeface.create("sans-serif-condensed", Typeface.BOLD_ITALIC)
        val sub = LinearLayout(this)
        sub.orientation = LinearLayout.HORIZONTAL
        sub.gravity = Gravity.CENTER_VERTICAL
        val dot = View(this)
        dot.background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(accent) }
        sub.addView(dot, LinearLayout.LayoutParams(dp(6), dp(6)).apply { rightMargin = dp(5) })
        val l = label(name, 11f, 0xFFAFBBD2.toInt())
        sub.addView(l)
        col.addView(value)
        col.addView(sub, LinearLayout.LayoutParams(-2, -2).apply { topMargin = dp(2) })
        if (isHz) hzBig = value else { cpuBig = value; cpuLabel = l }
        return col
    }

    private fun miniStat(res: Int): Pair<View, TextView> {
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        row.addView(icon(res, 17, accent))
        val t = label("--", 12f, Color.WHITE, true)
        t.setPadding(dp(4), 0, 0, 0)
        row.addView(t)
        return row to t
    }

    private fun buildTiles(): View {
        val grid = LinearLayout(this)
        grid.orientation = LinearLayout.VERTICAL

        val dndOn = getSharedPreferences("launcher", Context.MODE_PRIVATE).getInt("dnd_prev", -1) != -1

        val t1 = tile(R.drawable.ic_p_rocket, "Limpar RAM", false) { cleanMemory() }
        val t2 = tile(R.drawable.ic_p_moon, "Não perturbe", dndOn) { toggleDnd() }
        val t3 = tile(R.drawable.ic_p_timer, "00:00", false) {
            sessionStart = SystemClock.elapsedRealtime(); renderTimer()
        }
        timerText = t3.getChildAt(1) as TextView
        val t4 = tile(R.drawable.ic_p_palette, "Visual", false) {
            tab = Tab.VISUAL; refreshPanelInPlace()
        }
        val t5 = tile(R.drawable.ic_p_gamepad, "Launcher", false) {
            startActivity(Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        }
        val t6 = tile(R.drawable.ic_p_power, "Desligar", false) { stopSelf() }

        for (rowTiles in listOf(listOf(t1, t2, t3), listOf(t4, t5, t6))) {
            val row = LinearLayout(this)
            row.orientation = LinearLayout.HORIZONTAL
            for ((i, t) in rowTiles.withIndex()) {
                row.addView(t, LinearLayout.LayoutParams(0, dp(70), 1f).apply {
                    if (i > 0) leftMargin = dp(8)
                })
            }
            grid.addView(row, LinearLayout.LayoutParams(-1, -2).apply {
                if (grid.childCount > 0) topMargin = dp(8)
            })
        }
        return grid
    }

    private fun tile(iconRes: Int, text: String, active: Boolean, onClick: () -> Unit): LinearLayout {
        val v = LinearLayout(this)
        v.orientation = LinearLayout.VERTICAL
        v.gravity = Gravity.CENTER
        v.setPadding(dp(4), dp(6), dp(4), dp(6))
        v.background = CutDrawable(
            if (active) alpha(accent, 90) else 0x55223253,
            if (active) alpha(accent, 40) else 0x55101A30,
            if (active) accent else 0x44FFFFFF,
            accent, dpf(10f), dpf(1.1f), CutDrawable.BR
        )
        v.addView(icon(iconRes, 27, if (active) Color.WHITE else accent))
        val l = label(text, 10.5f, if (active) Color.WHITE else 0xFFD3DCEE.toInt(), true)
        l.maxLines = 1
        v.addView(l, LinearLayout.LayoutParams(-2, -2).apply { topMargin = dp(5) })
        pressable(v, onClick)
        staggerViews.add(v)
        return v
    }

    private fun mediaKey(code: Int) {
        val am = getSystemService(Context.AUDIO_SERVICE) as AudioManager
        val t = SystemClock.uptimeMillis()
        am.dispatchMediaKeyEvent(KeyEvent(t, t, KeyEvent.ACTION_DOWN, code, 0))
        am.dispatchMediaKeyEvent(KeyEvent(t, t, KeyEvent.ACTION_UP, code, 0))
    }

    /** Controle remoto de música: funciona com qualquer player (Spotify etc.), sem permissões extras. */
    private fun buildMusicCard(): View {
        val card = LinearLayout(this)
        card.orientation = LinearLayout.HORIZONTAL
        card.gravity = Gravity.CENTER_VERTICAL
        card.setPadding(dp(12), dp(8), dp(10), dp(8))
        card.background = CutDrawable(
            0x66141F38, 0x66090F1E, alpha(accent, 120), accent, dpf(12f), dpf(1.1f), CutDrawable.TL or CutDrawable.BR
        )
        card.addView(icon(R.drawable.ic_p_music, 22, accent))
        val info = LinearLayout(this)
        info.orientation = LinearLayout.VERTICAL
        info.addView(label("Música", 13f, Color.WHITE, true))
        val sub = label("Controla o player que estiver tocando", 10.5f, 0xFFAFBBD2.toInt()).apply {
            maxLines = 1; ellipsize = android.text.TextUtils.TruncateAt.END
        }
        musicSub = sub
        info.addView(sub, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(1) })
        card.addView(info, LinearLayout.LayoutParams(0, -2, 1f).apply { leftMargin = dp(10); rightMargin = dp(6) })

        fun ctl(res: Int, size: Int, filled: Boolean, key: Int): ImageView {
            val b = icon(res, if (filled) 20 else 18, if (filled) Color.WHITE else 0xFFE3EAF8.toInt())
            val pad = dp(if (filled) 10 else 9)
            b.setPadding(pad, pad, pad, pad)
            if (filled) b.background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(accent) }
            b.layoutParams = LinearLayout.LayoutParams(dp(size), dp(size))
            pressable(b) {
                mediaKey(key)
                // o callback atualiza sozinho; esta releitura cobre players que demoram a avisar
                handler.postDelayed({ setMusicState(isMusicPlaying()) }, 600)
            }
            return b
        }
        card.addView(ctl(R.drawable.ic_p_prev, 36, false, KeyEvent.KEYCODE_MEDIA_PREVIOUS))
        val play = ctl(R.drawable.ic_p_playpause, 42, true, KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE)
        musicBtn = play
        musicPlaying = isMusicPlaying()
        applyMusicState()
        card.addView(play, (play.layoutParams as LinearLayout.LayoutParams).apply { leftMargin = dp(2); rightMargin = dp(2) })
        card.addView(ctl(R.drawable.ic_p_next, 36, false, KeyEvent.KEYCODE_MEDIA_NEXT))
        return card
    }

    /** Há áudio de mídia (música/vídeo) tocando? Jogos usam outro tipo de uso e são ignorados. */
    private fun isMusicPlaying(): Boolean = runCatching {
        audioManager.activePlaybackConfigurations.any {
            it.audioAttributes.usage == android.media.AudioAttributes.USAGE_MEDIA
        }
    }.getOrDefault(false)

    private fun applyMusicState() {
        musicBtn?.setImageResource(if (musicPlaying) R.drawable.ic_p_pause else R.drawable.ic_p_play)
        musicSub?.put(if (musicPlaying) "Tocando agora" else "Pausado")
    }

    private fun setMusicState(playing: Boolean) {
        if (panel == null) return
        musicPlaying = playing
        applyMusicState()
    }

    /** Acompanha ao vivo se a música está tocando ou pausada (sem permissão extra). */
    private fun watchMusic() {
        if (playbackCb != null) return
        val cb = object : AudioManager.AudioPlaybackCallback() {
            override fun onPlaybackConfigChanged(configs: MutableList<android.media.AudioPlaybackConfiguration>?) {
                setMusicState(configs?.any {
                    it.audioAttributes.usage == android.media.AudioAttributes.USAGE_MEDIA
                } ?: false)
            }
        }
        playbackCb = cb
        audioManager.registerAudioPlaybackCallback(cb, handler)
    }

    private fun unwatchMusic() {
        playbackCb?.let { runCatching { audioManager.unregisterAudioPlaybackCallback(it) } }
        playbackCb = null
    }

    private fun buildColorCard(): View {
        val card = LinearLayout(this)
        card.orientation = LinearLayout.VERTICAL
        card.setPadding(dp(10), dp(8), dp(10), dp(8))
        card.background = CutDrawable(
            0x66141F38, 0x66090F1E, alpha(accent, 120), accent, dpf(12f), dpf(1.1f), CutDrawable.BR
        )

        val head = LinearLayout(this)
        head.orientation = LinearLayout.HORIZONTAL
        head.gravity = Gravity.CENTER_VERTICAL
        val title = label("COR DO PAINEL", 10f, 0xFF9AA8C2.toInt(), true)
        title.letterSpacing = 0.12f
        head.addView(title, LinearLayout.LayoutParams(0, -2, 1f))

        val side = LinearLayout(this)
        side.orientation = LinearLayout.HORIZONTAL
        side.gravity = Gravity.CENTER_VERTICAL
        side.setPadding(dp(9), dp(5), dp(9), dp(5))
        side.background = CutDrawable(0x33FFFFFF, 0x11FFFFFF, 0x44FFFFFF, accent, dpf(6f), dpf(1f), CutDrawable.BR)
        side.addView(icon(R.drawable.ic_p_swap, 15, accent))
        val st = label(if (right) "Lado: direita" else "Lado: esquerda", 10.5f, Color.WHITE, true)
        st.setPadding(dp(5), 0, 0, 0)
        side.addView(st)
        pressable(side) {
            right = !right
            AccentStore.writeRight(this, right)
            // fecha e reabre do outro lado
            removePanelNow()
            rebuildHandle()
            handleView?.visibility = View.GONE
            openPanel()
        }
        head.addView(side)
        card.addView(head)

        val sw = LinearLayout(this)
        sw.orientation = LinearLayout.HORIZONTAL
        sw.gravity = Gravity.CENTER_VERTICAL
        for (c in AccentStore.presets) {
            val sel = c == accent
            val dot = View(this)
            dot.background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(c)
                if (sel) setStroke(dp(2), Color.WHITE) else setStroke(dp(1), 0x44FFFFFF)
            }
            pressable(dot) { if (c != accent) setAccent(c) }
            sw.addView(dot, LinearLayout.LayoutParams(0, dp(if (sel) 26 else 22), 1f).apply {
                marginEnd = dp(4); marginStart = dp(4)
            })
        }
        card.addView(sw, LinearLayout.LayoutParams(-1, dp(30)).apply { topMargin = dp(8) })

        val hue = HueBar(this, accent) { picked -> handler.post { setAccent(picked) } }
        card.addView(hue, LinearLayout.LayoutParams(-1, dp(30)).apply { topMargin = dp(2) })
        return card
    }

    // ---------------------------------------------------------------- ações

    private fun cleanMemory() {
        val am = getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val before = MemoryInfoCompat.avail(am)
        Thread {
            Perf.boost(this, gamePkg ?: "")
            handler.postDelayed({
                val freed = ((MemoryInfoCompat.avail(am) - before) / 1_000_000L).coerceAtLeast(0)
                Toast.makeText(this, "Memória limpa: +$freed MB livres", Toast.LENGTH_SHORT).show()
                update()
            }, 700)
        }.start()
    }

    private fun toggleDnd() {
        if (!Dnd.hasAccess(this)) {
            Toast.makeText(this, "Permita o acesso a Não perturbar nas configurações do Android", Toast.LENGTH_LONG).show()
            return
        }
        val on = getSharedPreferences("launcher", Context.MODE_PRIVATE).getInt("dnd_prev", -1) != -1
        if (on) Dnd.restore(this) else Dnd.enable(this)
        refreshPanelInPlace()
    }

    // ---------------------------------------------------------------- dados ao vivo

    private class Sample(
        val hz: Float?, val ramFrac: Float, val pct: Int, val batTemp: Double,
        val charging: Boolean, val cpuT: Double?, val cpu: CpuInfo?
    )

    /** Leituras pesadas (arquivos do sistema, ActivityManager): rodam numa thread separada. */
    private fun sample(): Sample {
        val dm = getSystemService(Context.DISPLAY_SERVICE) as DisplayManager
        val hz = dm.getDisplay(Display.DEFAULT_DISPLAY)?.refreshRate
        val am = getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val mi = ActivityManager.MemoryInfo()
        am.getMemoryInfo(mi)
        val ramFrac = if (mi.totalMem > 0) (mi.totalMem - mi.availMem).toFloat() / mi.totalMem else 0f
        val b = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val level = b?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
        val scale = b?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100
        val pct = if (level >= 0 && scale > 0) level * 100 / scale else -1
        val batTemp = (b?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) ?: 0) / 10.0
        val st = b?.getIntExtra(BatteryManager.EXTRA_STATUS, -1) ?: -1
        val charging = st == BatteryManager.BATTERY_STATUS_CHARGING || st == BatteryManager.BATTERY_STATUS_FULL
        val raw = cpuTempPath?.let { readLong(it) }
        val cpuT = raw?.let { if (it > 1000) it / 1000.0 else it.toDouble() }?.takeIf { it in 1.0..120.0 }
        return Sample(hz, ramFrac, pct, batTemp, charging, cpuT, cpuInfo())
    }

    private fun TextView.put(cs: CharSequence) {
        if (text.toString() != cs.toString()) text = cs
    }

    /** Só mexe nas views (thread principal), e só quando o texto realmente mudou. */
    private fun render(s: Sample) {
        if (panel == null || closing) return
        usingCpu = s.cpu != null
        history.add(s.cpu?.ratio ?: s.ramFrac)
        while (history.size > GraphView.MAX) history.removeAt(0)
        graph?.setData(history)
        graphTitle?.put(if (usingCpu) "CARGA DA CPU" else "USO DE RAM")
        hzBig?.put(bigText(if (s.hz != null) "${Math.round(s.hz)}" else "--", "Hz"))
        if (s.cpu != null) {
            cpuBig?.put(bigText("${(s.cpu.ratio * 100).toInt()}", "%"))
            cpuLabel?.put("CPU · ${"%.1f".format(s.cpu.maxMhz / 1000.0)} GHz")
        } else {
            cpuBig?.put(bigText("${(s.ramFrac * 100).toInt()}", "%"))
            cpuLabel?.put("RAM")
        }
        tempText?.put(
            if (s.cpuT != null) "${"%.0f".format(s.cpuT)}° / ${"%.0f".format(s.batTemp)}°"
            else "${"%.0f".format(s.batTemp)}°"
        )
        ramText?.put("${(s.ramFrac * 100).toInt()}%")
        batText?.put((if (s.charging) "⚡" else "") + (if (s.pct >= 0) "${s.pct}%" else "--"))
        renderTimer()
    }

    private fun renderTimer() {
        val secs = (SystemClock.elapsedRealtime() - sessionStart) / 1000
        timerText?.put("%02d:%02d".format(secs / 60, secs % 60))
    }

    /** Pede uma leitura nova agora (fora do ciclo de 1 s). */
    private fun update() {
        bg.post {
            val smp = runCatching { sample() }.getOrNull()
            if (smp != null) handler.post { render(smp) }
        }
    }

    private class CpuInfo(val ratio: Float, val maxMhz: Long)

    private fun cpuInfo(): CpuInfo? {
        val n = Runtime.getRuntime().availableProcessors()
        var maxCur = 0L
        var ratioSum = 0.0
        var count = 0
        val maxes = cpuMax ?: LongArray(n) { i ->
            readLong("/sys/devices/system/cpu/cpu$i/cpufreq/cpuinfo_max_freq") ?: 0L
        }.also { cpuMax = it }
        for (i in 0 until n) {
            val max = maxes[i]
            if (max <= 0) continue
            val cur = readLong("/sys/devices/system/cpu/cpu$i/cpufreq/scaling_cur_freq") ?: continue
            if (cur > maxCur) maxCur = cur
            ratioSum += cur.toDouble() / max
            count++
        }
        if (count == 0) return null
        return CpuInfo((ratioSum / count).toFloat().coerceIn(0f, 1f), maxCur / 1000)
    }

    private fun readLong(path: String): Long? =
        runCatching { File(path).readText().trim().toLongOrNull() }.getOrNull()

    private fun findCpuTempPath(): String? {
        val zones = File("/sys/class/thermal").listFiles()
            ?.filter { it.name.startsWith("thermal_zone") } ?: return null
        for (key in listOf("cpu", "soc", "tsens")) {
            for (z in zones) {
                val type = runCatching { File(z, "type").readText().trim().lowercase() }.getOrNull() ?: continue
                val tempPath = File(z, "temp").path
                if (type.contains(key) && readLong(tempPath) != null) return tempPath
            }
        }
        return null
    }

    private object MemoryInfoCompat {
        fun avail(am: ActivityManager): Long {
            val mi = ActivityManager.MemoryInfo()
            am.getMemoryInfo(mi)
            return mi.availMem
        }
    }

    companion object {
        private const val CHANNEL = "overlay"
        const val EXTRA_GAME = "game"
        // Curvas no estilo iOS (sheet): saída longa e suave.
        private val IOS = PathInterpolator(0.32f, 0.72f, 0f, 1f)
        private val IOS_OUT = PathInterpolator(0.4f, 0f, 0.2f, 1f)
    }
}
