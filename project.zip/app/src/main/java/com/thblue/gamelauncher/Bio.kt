package com.thblue.gamelauncher

import android.app.Activity
import android.content.Context
import android.content.pm.PackageManager
import android.hardware.biometrics.BiometricManager
import android.hardware.biometrics.BiometricPrompt
import android.os.Build
import android.os.CancellationSignal

/** Impressão digital pelo próprio Android (sem bibliotecas extras). Precisa do Android 9 ou mais novo. */
object Bio {
    fun available(ctx: Context): Boolean {
        if (Build.VERSION.SDK_INT < 28) return false
        return runCatching {
            when {
                Build.VERSION.SDK_INT >= 30 ->
                    ctx.getSystemService(BiometricManager::class.java)
                        ?.canAuthenticate(BiometricManager.Authenticators.BIOMETRIC_WEAK) == BiometricManager.BIOMETRIC_SUCCESS
                Build.VERSION.SDK_INT == 29 ->
                    @Suppress("DEPRECATION")
                    (ctx.getSystemService(BiometricManager::class.java)?.canAuthenticate() == BiometricManager.BIOMETRIC_SUCCESS)
                else -> ctx.packageManager.hasSystemFeature(PackageManager.FEATURE_FINGERPRINT)
            }
        }.getOrDefault(false)
    }

    /** Mostra a janela da digital. [onNegative] roda se a pessoa tocar no botão de baixo (ex.: "Usar PIN"). */
    fun prompt(activity: Activity?, title: String, negative: String, onSuccess: () -> Unit, onNegative: () -> Unit = {}) {
        if (Build.VERSION.SDK_INT < 28 || activity == null) return
        runCatching {
            val executor = activity.mainExecutor
            val builder = BiometricPrompt.Builder(activity)
                .setTitle(title)
                .setNegativeButton(negative, executor) { _, _ -> onNegative() }
            if (Build.VERSION.SDK_INT >= 30) {
                builder.setAllowedAuthenticators(BiometricManager.Authenticators.BIOMETRIC_WEAK)
            }
            builder.build().authenticate(
                CancellationSignal(), executor,
                object : BiometricPrompt.AuthenticationCallback() {
                    override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult?) {
                        onSuccess()
                    }
                }
            )
        }
    }
}
