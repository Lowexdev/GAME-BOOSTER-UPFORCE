package com.thblue.gamelauncher

import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

enum class PerfMode(val label: String, val desc: String) {
    ECONOMY("Economia", "Menor taxa de atualização, brilho reduzido e sem animações. Gasta menos bateria."),
    PERFORMANCE("Desempenho", "Taxa de atualização máxima da tela (ex.: 90 Hz) com uso normal de bateria."),
    EXTREME("Desempenho extremo", "Maior taxa de atualização e tela sempre ligada enquanto o launcher está aberto.")
}

data class AppEntry(val label: String, val pkg: String, val isGame: Boolean, val isSystem: Boolean = false)

object GameRepo {
    fun load(ctx: Context): List<AppEntry> {
        val pm = ctx.packageManager
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        return pm.queryIntentActivities(intent, 0).mapNotNull { ri ->
            val ai = ri.activityInfo.applicationInfo
            if (ai.packageName == ctx.packageName) return@mapNotNull null
            @Suppress("DEPRECATION")
            val isGame = ai.category == ApplicationInfo.CATEGORY_GAME ||
                (ai.flags and ApplicationInfo.FLAG_IS_GAME) != 0
            AppEntry(
                ri.loadLabel(pm).toString(),
                ai.packageName,
                isGame,
                (ai.flags and ApplicationInfo.FLAG_SYSTEM) != 0
            )
        }.distinctBy { it.pkg }.sortedBy { it.label.lowercase() }
    }
}

/** Estado do launcher. Cada perfil guarda seu próprio modo, som, cor e lista de jogos. */
class LauncherState(private val ctx: Context) {
    private val sp = ctx.getSharedPreferences("launcher", Context.MODE_PRIVATE)

    val profiles = mutableStateListOf<String>()
    val pinned = mutableStateListOf<String>()
    val hidden = mutableStateListOf<String>()
    var hasPin by mutableStateOf(sp.contains("pin_hash"))
        private set
    var bioEnabled by mutableStateOf(sp.getBoolean("bio", false))
        private set
    val isSetUp: Boolean get() = hasPin || bioEnabled
    var bgLauncher by mutableStateOf<String?>(null)
        private set
    var bgPanel by mutableStateOf<String?>(null)
        private set
    /** Jogos secretos: somem de tudo até o PIN ser digitado (segurar o título "GAMES"). */
    val secret = mutableStateListOf<String>()

    var unlocked by mutableStateOf(false)
        private set

    var current by mutableStateOf("Jogador 1")
        private set
    var mode by mutableStateOf(PerfMode.PERFORMANCE)
        private set
    var sound by mutableStateOf(true)
        private set
    var overlay by mutableStateOf(false)
        private set
    var dnd by mutableStateOf(false)
        private set
    var accentColor by mutableIntStateOf(AccentStore.DEFAULT)
        private set
    var apps by mutableStateOf<List<AppEntry>>(emptyList())
        private set

    init {
        val saved = sp.getString("profiles", null)?.split("|")?.filter { it.isNotBlank() }.orEmpty()
        profiles.addAll(if (saved.isEmpty()) listOf("Jogador 1") else saved)
        val cur = sp.getString("current", null)
        load(if (cur != null && cur in profiles) cur else profiles.first())
        persistProfiles()
    }

    /** Tela inicial: normal = só os jogos visíveis (sem os ocultos); área oculta (PIN) = SÓ os ocultos. */
    val games: List<AppEntry>
        get() = if (unlocked) apps.filter { it.pkg in secret }
        else apps.filter { isVisible(it) && it.pkg !in secret }

    /** "Gerenciar jogos" nunca mostra os ocultos: eles só se gerenciam dentro da área oculta. */
    val manageable: List<AppEntry>
        get() = apps.filter { it.pkg !in secret }

    /** Tudo que dá para esconder: jogos primeiro, depois os outros apps. */
    val hideCandidates: List<AppEntry>
        get() = apps.sortedWith(compareByDescending<AppEntry> { it.isGame }.thenBy { it.label.lowercase() })

    // ---- PIN dos jogos secretos
    private fun hash(pin: String): String =
        java.security.MessageDigest.getInstance("SHA-256")
            .digest(("gb:$pin").toByteArray()).joinToString("") { "%02x".format(it) }

    fun setPin(pin: String): Boolean {
        if (pin.length !in 4..6 || !pin.all { it.isDigit() }) return false
        sp.edit().putString("pin_hash", hash(pin)).apply()
        hasPin = true
        unlocked = true
        return true
    }

    /** Só dá para tirar o PIN se a digital estiver ligada (senão ficaria sem trava nenhuma). */
    fun clearPin() {
        if (!bioEnabled) return
        sp.edit().remove("pin_hash").apply()
        hasPin = false
    }

    fun setBio(on: Boolean) {
        if (!on && !hasPin) return
        bioEnabled = on
        sp.edit().putBoolean("bio", on).apply()
    }

    fun unlockWithBio() { unlocked = true }

    // ---- fotos de fundo (launcher e painel)
    suspend fun setBg(kind: String, uri: android.net.Uri) {
        val profile = current
        val path = withContext(Dispatchers.IO) { BgStore.save(ctx, profile, kind, uri) } ?: return
        if (profile != current) return
        if (kind == BgStore.LAUNCHER) bgLauncher = path else bgPanel = path
    }

    fun clearBg(kind: String) {
        BgStore.clear(ctx, current, kind)
        if (kind == BgStore.LAUNCHER) bgLauncher = null else bgPanel = null
    }

    fun unlock(pin: String): Boolean {
        if (hash(pin) != sp.getString("pin_hash", null)) return false
        unlocked = true
        return true
    }

    fun lock() { unlocked = false }

    fun toggleSecret(app: AppEntry) {
        if (!unlocked) return
        if (app.pkg in secret) secret.remove(app.pkg) else secret.add(app.pkg)
        sp.edit().putString(key("secret"), secret.joinToString(",")).apply()
    }

    fun isVisible(app: AppEntry): Boolean =
        (app.isGame && app.pkg !in hidden) || app.pkg in pinned

    suspend fun refreshApps() {
        apps = withContext(Dispatchers.IO) { GameRepo.load(ctx) }
    }

    private fun key(k: String) = "p.$current.$k"

    private fun readList(k: String): List<String> =
        (sp.getString(k, "") ?: "").split(",").filter { it.isNotBlank() }

    private fun load(name: String) {
        current = name
        mode = runCatching {
            PerfMode.valueOf(sp.getString(key("mode"), null) ?: "PERFORMANCE")
        }.getOrDefault(PerfMode.PERFORMANCE)
        sound = sp.getBoolean(key("sound"), true)
        overlay = sp.getBoolean(key("overlay"), false)
        dnd = sp.getBoolean(key("dnd"), false)
        accentColor = AccentStore.readFor(ctx, name)
        pinned.clear(); pinned.addAll(readList(key("pinned")))
        hidden.clear(); hidden.addAll(readList(key("hidden")))
        secret.clear(); secret.addAll(readList(key("secret")))
        bgLauncher = BgStore.pathFor(ctx, name, BgStore.LAUNCHER)
        bgPanel = BgStore.pathFor(ctx, name, BgStore.PANEL)
        sp.edit().putString("current", name).apply()
    }

    private fun persistProfiles() {
        sp.edit().putString("profiles", profiles.joinToString("|")).apply()
    }

    fun switchTo(name: String) {
        if (name in profiles) load(name)
    }

    fun createProfile(raw: String) {
        val name = raw.replace("|", "").replace(",", "").trim()
        if (name.isEmpty() || name in profiles) return
        profiles.add(name)
        persistProfiles()
        load(name)
    }

    fun deleteProfile(name: String) {
        if (profiles.size <= 1 || name !in profiles) return
        profiles.remove(name)
        val prefix = "p.$name."
        val editor = sp.edit()
        sp.all.keys.filter { it.startsWith(prefix) }.forEach { editor.remove(it) }
        editor.apply()
        persistProfiles()
        if (name == current) load(profiles.first())
    }

    fun changeMode(m: PerfMode) {
        mode = m
        sp.edit().putString(key("mode"), m.name).apply()
    }

    fun changeSound(on: Boolean) {
        sound = on
        sp.edit().putBoolean(key("sound"), on).apply()
    }

    fun changeOverlay(on: Boolean) {
        overlay = on
        sp.edit().putBoolean(key("overlay"), on).apply()
    }

    fun changeDnd(on: Boolean) {
        dnd = on
        sp.edit().putBoolean(key("dnd"), on).apply()
    }

    fun chooseAccent(argb: Int) {
        accentColor = argb
        sp.edit().putInt(key("accentColor"), argb).apply()
    }

    /** Relê tudo do disco (o painel do jogo pode ter mudado cor ou "Não perturbe" enquanto o launcher ficou em segundo plano). */
    fun reloadFromPrefs() = load(current)

    fun toggle(app: AppEntry) {
        if (isVisible(app)) {
            pinned.remove(app.pkg)
            if (app.isGame && app.pkg !in hidden) hidden.add(app.pkg)
        } else {
            if (app.isGame) hidden.remove(app.pkg) else if (app.pkg !in pinned) pinned.add(app.pkg)
        }
        sp.edit()
            .putString(key("pinned"), pinned.joinToString(","))
            .putString(key("hidden"), hidden.joinToString(","))
            .apply()
    }
}
