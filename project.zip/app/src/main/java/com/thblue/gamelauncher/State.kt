package com.thblue.gamelauncher

import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

enum class PerfMode(val label: String, val desc: String) {
    ECONOMY("Economia", "Menor taxa de atualização, brilho reduzido e sem animações. Gasta menos bateria."),
    PERFORMANCE("Desempenho", "Equilíbrio entre fluidez e bateria. Configuração padrão do sistema."),
    EXTREME("Desempenho extremo", "Maior taxa de atualização, tela sempre ligada e limpa apps em segundo plano antes de abrir o jogo.")
}

data class AppEntry(val label: String, val pkg: String, val isGame: Boolean)

object GameRepo {
    fun load(ctx: Context): List<AppEntry> {
        val pm = ctx.packageManager
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        return pm.queryIntentActivities(intent, 0).mapNotNull { ri ->
            val ai = ri.activityInfo.applicationInfo
            if (ai.packageName == ctx.packageName) return@mapNotNull null
            @Suppress("DEPRECATION")
            val isGame = ai.category == ApplicationInfo.CATEGORY_GAME ||
                (ai.flags and ApplicationInfo.FLAG_IS_GAME) != 0
            AppEntry(ri.loadLabel(pm).toString(), ai.packageName, isGame)
        }.distinctBy { it.pkg }.sortedBy { it.label.lowercase() }
    }
}

/** Estado do launcher. Cada perfil guarda seu próprio modo, som, cor e lista de jogos. */
class LauncherState(private val ctx: Context) {
    private val sp = ctx.getSharedPreferences("launcher", Context.MODE_PRIVATE)

    val profiles = mutableStateListOf<String>()
    val pinned = mutableStateListOf<String>()
    val hidden = mutableStateListOf<String>()

    var current by mutableStateOf("Jogador 1")
        private set
    var mode by mutableStateOf(PerfMode.PERFORMANCE)
        private set
    var sound by mutableStateOf(true)
        private set
    var accentIndex by mutableIntStateOf(0)
        private set
    var apps by mutableStateOf<List<AppEntry>>(emptyList())
        private set

    init {
        val saved = sp.getString("profiles", null)?.split("|")?.filter { it.isNotBlank() }.orEmpty()
        profiles.addAll(if (saved.isEmpty()) listOf("Jogador 1") else saved)
        val cur = sp.getString("current", null)
        load(if (cur != null && cur in profiles) cur else profiles.first())
        persistProfiles()
    }

    val games: List<AppEntry>
        get() = apps.filter { isVisible(it) }

    fun isVisible(app: AppEntry): Boolean =
        (app.isGame && app.pkg !in hidden) || app.pkg in pinned

    suspend fun refreshApps() {
        apps = withContext(Dispatchers.IO) { GameRepo.load(ctx) }
    }

    private fun key(k: String) = "p.$current.$k"

    private fun readList(k: String): List<String> =
        (sp.getString(k, "") ?: "").split(",").filter { it.isNotBlank() }

    private fun load(name: String) {
        current = name
        mode = runCatching {
            PerfMode.valueOf(sp.getString(key("mode"), null) ?: "PERFORMANCE")
        }.getOrDefault(PerfMode.PERFORMANCE)
        sound = sp.getBoolean(key("sound"), true)
        accentIndex = sp.getInt(key("accent"), 0)
        pinned.clear(); pinned.addAll(readList(key("pinned")))
        hidden.clear(); hidden.addAll(readList(key("hidden")))
        sp.edit().putString("current", name).apply()
    }

    private fun persistProfiles() {
        sp.edit().putString("profiles", profiles.joinToString("|")).apply()
    }

    fun switchTo(name: String) {
        if (name in profiles) load(name)
    }

    fun createProfile(raw: String) {
        val name = raw.replace("|", "").replace(",", "").trim()
        if (name.isEmpty() || name in profiles) return
        profiles.add(name)
        persistProfiles()
        load(name)
    }

    fun deleteProfile(name: String) {
        if (profiles.size <= 1 || name !in profiles) return
        profiles.remove(name)
        val prefix = "p.$name."
        val editor = sp.edit()
        sp.all.keys.filter { it.startsWith(prefix) }.forEach { editor.remove(it) }
        editor.apply()
        persistProfiles()
        if (name == current) load(profiles.first())
    }

    fun changeMode(m: PerfMode) {
        mode = m
        sp.edit().putString(key("mode"), m.name).apply()
    }

    fun changeSound(on: Boolean) {
        sound = on
        sp.edit().putBoolean(key("sound"), on).apply()
    }

    fun setAccent(i: Int) {
        accentIndex = i
        sp.edit().putInt(key("accent"), i).apply()
    }

    fun toggle(app: AppEntry) {
        if (isVisible(app)) {
            pinned.remove(app.pkg)
            if (app.isGame && app.pkg !in hidden) hidden.add(app.pkg)
        } else {
            if (app.isGame) hidden.remove(app.pkg) else if (app.pkg !in pinned) pinned.add(app.pkg)
        }
        sp.edit()
            .putString(key("pinned"), pinned.joinToString(","))
            .putString(key("hidden"), hidden.joinToString(","))
            .apply()
    }
}
